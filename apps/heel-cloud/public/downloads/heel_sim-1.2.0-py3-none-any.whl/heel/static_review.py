"""Pure static ProductModel comparison and launch-risk analysis."""
from __future__ import annotations

from dataclasses import dataclass, field
import json
from typing import Any, Mapping

from .product_model import ProductModelError, validate_product_model
from .review_rules import is_broad_scope


SURFACE_FIELDS = [
    "endpoints_routes",
    "exports",
    "meters",
    "billing_objects",
    "plans",
    "coupons_promotions",
    "features_flags",
    "integration_oauth_apps",
    "webhooks",
    "support_admin_actions",
    "agent_tools",
    "mcp_connectors",
    "tenants",
    "data_classes",
    "declared_controls",
]

_MISSING_VALUES = {"", "missing", "none", "false", "disabled", "off", "no", "weak", "client", "client_only"}
_LOW_REACH_PLANS = {"trial", "free", "starter", "basic"}
_SCOPE_RANK = {
    "own_tenant": 1,
    "tenant": 1,
    "workspace": 2,
    "org": 3,
    "global": 4,
    "all_tenants": 4,
    "all": 4,
}


@dataclass(frozen=True)
class ChangedSurface:
    surface_type: str
    surface_id: str
    change_type: str
    before: dict[str, Any] | None
    after: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        out = {
            "surface_type": self.surface_type,
            "surface_id": self.surface_id,
            "change_type": self.change_type,
            "after": self.after,
        }
        if self.before is not None:
            out["before"] = self.before
        return out


@dataclass(frozen=True)
class RiskFinding:
    surface_type: str
    surface_id: str
    risk: str
    severity: str
    control: str
    reason: str
    reachable: bool
    evidence_state: str = "inferred"
    rule_source: str = "unknown"
    execution_disposition: str = "static_only"

    def to_dict(self) -> dict[str, Any]:
        return {
            "surface_type": self.surface_type,
            "surface_id": self.surface_id,
            "risk": self.risk,
            "severity": self.severity,
            "control": self.control,
            "reason": self.reason,
            "reachable": self.reachable,
            "evidence_state": self.evidence_state,
            "rule_source": self.rule_source,
            "execution_disposition": self.execution_disposition,
        }


@dataclass(frozen=True)
class SuggestedRegression:
    surface_type: str
    surface_id: str
    name: str
    expected_status: str
    scenario_hint: str
    safety: str = "model-only, canary-contained; no live probing"

    def to_dict(self) -> dict[str, Any]:
        return {
            "surface_type": self.surface_type,
            "surface_id": self.surface_id,
            "name": self.name,
            "expected_status": self.expected_status,
            "scenario_hint": self.scenario_hint,
            "safety": self.safety,
        }


@dataclass(frozen=True)
class LaunchReview:
    product_id: str
    changed_surfaces: list[ChangedSurface] = field(default_factory=list)
    new_abuse_affordances: list[RiskFinding] = field(default_factory=list)
    high_risk_missing_controls: list[RiskFinding] = field(default_factory=list)
    recommended_controls: list[RiskFinding] = field(default_factory=list)
    suggested_regression_tests: list[SuggestedRegression] = field(default_factory=list)
    launch_gate_status: str = "pass"
    safety: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "product_id": self.product_id,
            "launch_gate_status": self.launch_gate_status,
            "changed_surfaces": [s.to_dict() for s in self.changed_surfaces],
            "new_abuse_affordances": [f.to_dict() for f in self.new_abuse_affordances],
            "high_risk_missing_controls": [f.to_dict() for f in self.high_risk_missing_controls],
            "recommended_controls": [f.to_dict() for f in self.recommended_controls],
            "suggested_regression_tests": [r.to_dict() for r in self.suggested_regression_tests],
            "safety": dict(self.safety),
        }


def review_product_models(before: Mapping[str, Any], after: Mapping[str, Any]) -> LaunchReview:
    """Compare two sanitized ProductModel dictionaries and produce a launch review."""
    _validate_or_raise(before, "before")
    _validate_or_raise(after, "after")
    changed = _changed_surfaces(before, after)
    risks = []
    for surface in changed:
        risks.extend(_risk_findings(surface))
    # An operation may also be represented as an export; count each invariant once.
    identities = {(s.surface_type, s.surface_id):
                  (s.after.get("method"), s.after.get("route")) for s in changed}
    deduped = {}
    for risk in risks:
        location = identities[(risk.surface_type, risk.surface_id)]
        key = (location if all(location) else (risk.surface_type, risk.surface_id), risk.risk)
        deduped[key] = risk
    risks = [deduped[key] for key in deduped]
    high = [r for r in risks if r.severity == "block"]
    gate = "block" if high else "warn" if risks else "pass"
    regressions = _suggested_regressions(risks)
    return LaunchReview(
        product_id=str(after.get("product_id") or before.get("product_id") or ""),
        changed_surfaces=changed,
        new_abuse_affordances=risks,
        high_risk_missing_controls=high,
        recommended_controls=risks,
        suggested_regression_tests=regressions,
        launch_gate_status=gate,
        safety={
            "mode": "static ProductModel diff",
            "live_probing": False,
            "network_calls": False,
            "requires_signed_scope_for_live_or_staging_runs": True,
            "canary_only": True,
        },
    )


def _validate_or_raise(model: Mapping[str, Any], label: str) -> None:
    result = validate_product_model(model)
    if not result.ok:
        raise ProductModelError(f"{label} ProductModel invalid: {'; '.join(result.errors)}")


def _changed_surfaces(before: Mapping[str, Any], after: Mapping[str, Any]) -> list[ChangedSurface]:
    changed: list[ChangedSurface] = []
    for field_name in SURFACE_FIELDS:
        before_items = _items_by_id(before.get(field_name, []), field_name)
        after_items = _items_by_id(after.get(field_name, []), field_name)
        for sid in sorted(after_items):
            after_item = after_items[sid]
            before_item = before_items.get(sid)
            if before_item is None:
                changed.append(ChangedSurface(field_name, sid, "added", None, after_item))
            elif _stable_json(before_item) != _stable_json(after_item):
                changed.append(ChangedSurface(field_name, sid, "changed", before_item, after_item))
    return changed


def _risk_findings(surface: ChangedSurface) -> list[RiskFinding]:
    props = surface.after
    if surface.surface_type == "exports":
        return _export_risks(surface, props)
    if surface.surface_type == "endpoints_routes":
        return _endpoint_risks(surface, props)
    if surface.surface_type in {"meters", "billing_objects"}:
        return _meter_risks(surface, props)
    if surface.surface_type == "coupons_promotions":
        return _coupon_risks(surface, props)
    if surface.surface_type == "integration_oauth_apps":
        return _oauth_risks(surface, props)
    if surface.surface_type == "support_admin_actions":
        return _admin_action_risks(surface, props)
    if surface.surface_type in {"agent_tools", "mcp_connectors"}:
        return _agent_surface_risks(surface, props)
    if surface.surface_type == "features_flags":
        return _feature_flag_risks(surface, props)
    if surface.surface_type in {"tenants", "data_classes", "declared_controls"}:
        return _tenant_data_control_risks(surface, props)
    return []


def _export_risks(surface: ChangedSurface, props: Mapping[str, Any]) -> list[RiskFinding]:
    if props.get("bulk_access_permitted") is True:
        return []
    findings = []
    entitlement_missing = _bad_control(_first(props, "entitlement_check", "authz_check", "guard", "guard_present"))
    quota_missing = _bad_control(_first(props, "tenant_quota", "quota", "rate_limit", "export_limit"))
    if entitlement_missing:
        findings.append(_finding(
            surface,
            risk="export_without_entitlement",
            severity="block" if _reachable(props) else "warn",
            control="server-side entitlement check",
            reason=f"new {surface.surface_id} export reachable without server-side entitlement check",
            reachable=_reachable(props),
        ))
    if quota_missing:
        findings.append(_finding(
            surface,
            risk="export_without_tenant_quota",
            severity="block" if _reachable(props) else "warn",
            control="tenant quota",
            reason=f"new {surface.surface_id} export lacks tenant quota or rate limit",
            reachable=_reachable(props),
        ))
    return findings


def _endpoint_risks(surface: ChangedSurface, props: Mapping[str, Any]) -> list[RiskFinding]:
    findings = _ui_backing_endpoint_risks(surface, props)
    text = _text(props, "id", "name", "route", "path")
    if "export" in text:
        findings.extend(_export_risks(surface, props))
        return findings
    tenant_missing = _bad_control(_first(props, "tenant_filter", "tenant_check", "tenant_isolation"))
    if not tenant_missing:
        return findings
    findings.append(_finding(
        surface,
        risk="endpoint_without_tenant_filter",
        severity="block" if _reachable(props) else "warn",
        control="tenant filter",
        reason=f"new {surface.surface_id} endpoint lacks server-side tenant filtering",
        reachable=_reachable(props),
    ))
    return findings


def _ui_backing_endpoint_risks(surface: ChangedSurface, props: Mapping[str, Any]) -> list[RiskFinding]:
    ui_backing = _truthy(_first(props, "ui_backing_endpoint", "interactive_ui_endpoint", "browser_endpoint"))
    paid_equivalent = _truthy(_first(props, "paid_api_equivalent", "bulk_api_equivalent", "api_equivalent"))
    if not (ui_backing and paid_equivalent):
        return []

    required = str(_first(props, "required_plan", "entitlement_plan", "min_plan", "plan_required") or "").lower()
    reachable = str(_first(props, "reachable_by_plan", "granted_plan", "current_plan", "observed_plan") or "").lower()
    plan_mismatch = bool(required and reachable and required != reachable)
    entitlement_missing = _bad_control(_first(props, "entitlement_check", "authz_check", "guard", "guard_present"))
    quota_missing = _bad_control(_first(props, "lookup_quota", "lookup_limit", "rate_limit", "tenant_quota", "quota"))
    automation_missing = _bad_control(_first(props, "automation_guard", "anti_automation", "bot_protection", "human_challenge"))
    if not (plan_mismatch or entitlement_missing or quota_missing or automation_missing):
        return []

    reachable_signal = _reachable(props) or plan_mismatch
    return [_finding(
        surface,
        risk="ui_backing_endpoint_paid_api_bypass",
        severity="block" if reachable_signal else "warn",
        control="shared UI/API entitlement and lookup quota",
        reason=f"new {surface.surface_id} UI backing endpoint can be scripted as unpriced bulk API access",
        reachable=reachable_signal,
    )]


def _meter_risks(surface: ChangedSurface, props: Mapping[str, Any]) -> list[RiskFinding]:
    if not _truthy(_first(props, "billable", "cost_bearing", "metered", "charges_money")):
        return []
    accounting_missing = _bad_control(_first(props, "server_side_accounting", "server_authoritative", "meter_accounting"))
    quota_missing = _bad_control(_first(props, "quota", "cost_ceiling", "spend_limit"))
    if not (accounting_missing or quota_missing):
        return []
    return [_finding(
        surface,
        risk="unmetered_billable_resource",
        severity="warn",
        control="server-side meter accounting and cost ceiling",
        reason=f"new {surface.surface_id} billable surface lacks server-side accounting or cost ceiling",
        reachable=_reachable(props),
    )]


def _coupon_risks(surface: ChangedSurface, props: Mapping[str, Any]) -> list[RiskFinding]:
    if props.get("stacking_permitted") is True:
        return []
    stackable = _truthy(props.get("stackable"))
    redemption_missing = _bad_control(_first(props, "redemption_limit", "max_redemptions", "per_account_limit", "proof_of_uniqueness"))
    if not (stackable and redemption_missing):
        return []
    discount = _number(_first(props, "discount_percent", "discount"))
    severe_discount = discount >= 90 or str(props.get("applies_to", "")).lower() in {"all_plans", "all"}
    severity = "block" if severe_discount and _reachable(props) else "warn"
    return [_finding(
        surface,
        risk="stackable_coupon_without_redemption_limit",
        severity=severity,
        control="redemption limit and proof of uniqueness",
        reason=f"new {surface.surface_id} stackable coupon lacks redemption limit",
        reachable=_reachable(props),
    )]


def _oauth_risks(surface: ChangedSurface, props: Mapping[str, Any]) -> list[RiskFinding]:
    scope_value = str(_first(props, "scope", "granted_scope", "oauth_scope") or "").strip().lower()
    granted = {s.strip().lower() for s in _to_list(_first(props, "granted_scopes", "scopes"))}
    needed = {s.strip().lower() for s in _to_list(_first(props, "needed_scopes", "required_scopes", "intended_scopes"))}
    scope_all = is_broad_scope(scope_value)
    granted_high_scope = any(is_broad_scope(scope) for scope in granted)
    excess = bool(granted and needed and not granted.issubset(needed))
    if not (scope_all or granted_high_scope or excess):
        return []
    auto = _truthy(_first(props, "auto_approved", "auto_install", "default_approved"))
    low_role = str(_first(props, "installable_by_role", "reachable_by_role", "role") or "").lower() in {"member", "user", "anyone", "anonymous"}
    severity = "block" if auto and low_role else "warn"
    return [_finding(
        surface,
        risk="oauth_scope_overbroad",
        severity=severity,
        control="OAuth scope minimization and approval",
        reason=f"new {surface.surface_id} OAuth app grants overbroad scope",
        reachable=_reachable(props) or auto or low_role,
    )]


def _admin_action_risks(surface: ChangedSurface, props: Mapping[str, Any]) -> list[RiskFinding]:
    required = str(_first(props, "required_role", "min_role", "intended_role") or "").lower()
    reachable = str(_first(props, "reachable_by_role", "granted_role", "observed_role") or "").lower()
    audit_missing = _bad_control(_first(props, "audit_logged", "audit_event", "audit_event_id"))
    if not required and not audit_missing:
        return []
    role_mismatch = bool(
        reachable and reachable != required and reachable in {"member", "user", "support"}
    )
    if not (role_mismatch or audit_missing):
        return []
    severity = "block" if role_mismatch and audit_missing else "warn"
    return [_finding(
        surface,
        risk="admin_action_without_role_or_audit_control",
        severity=severity,
        control="admin role gate and audit event",
        reason=f"new {surface.surface_id} support/admin action lacks role or audit controls",
        reachable=_reachable(props) or role_mismatch,
    )]


def _agent_surface_risks(surface: ChangedSurface, props: Mapping[str, Any]) -> list[RiskFinding]:
    granted = str(_first(props, "granted_scope", "effective_scope", "scope") or "").lower()
    intended = str(_first(props, "intended_scope", "required_scope", "declared_scope") or "").lower()
    if not granted or not intended or not _scope_wider(granted, intended):
        return []
    return [_finding(
        surface,
        risk="agent_surface_overscope",
        severity="block",
        control="tool scope minimization",
        reason=f"new {surface.surface_id} agent/MCP surface grants {granted} beyond intended {intended}",
        reachable=True,
    )]


def _feature_flag_risks(surface: ChangedSurface, props: Mapping[str, Any]) -> list[RiskFinding]:
    required = str(_first(props, "required_plan", "entitlement_plan", "min_plan") or "").lower()
    reachable = str(_first(props, "reachable_by_plan", "granted_plan", "current_plan") or "").lower()
    client_gate = str(_first(props, "gated_by", "guard") or "").lower() in {"client", "client_only"}
    if not (required and reachable and required != reachable) and not client_gate:
        return []
    return [_finding(
        surface,
        risk="feature_flag_plan_mismatch",
        severity="warn",
        control="server-side feature entitlement check",
        reason=f"new {surface.surface_id} feature flag may be reachable outside intended plan",
        reachable=_reachable(props),
    )]


def _tenant_data_control_risks(surface: ChangedSurface, props: Mapping[str, Any]) -> list[RiskFinding]:
    control_removed = surface.surface_type == "declared_controls" and str(props.get("status", "")).lower() in {"removed", "disabled"}
    sensitive_data = surface.surface_type == "data_classes" and _truthy(_first(props, "sensitive", "regulated", "customer_data"))
    if not (control_removed or sensitive_data):
        return []
    return [_finding(
        surface,
        risk="tenant_or_data_control_change",
        severity="warn",
        control="tenant/data control review",
        reason=f"changed {surface.surface_id} tenant/data control needs abuse review",
        reachable=False,
    )]


def _finding(surface: ChangedSurface, *, risk: str, severity: str, control: str, reason: str, reachable: bool) -> RiskFinding:
    rule = surface.after.get("business_rule") or surface.after.get("required_plan")
    qualification = "Customer-declared model hypothesis; behavior unverified. " if rule else "Investigation prompt; intended product rule unknown and behavior unverified. "
    return RiskFinding(surface.surface_type, surface.surface_id, risk, severity, control, qualification + reason, reachable, "inferred", str(surface.after.get("rule_source") or "unknown"))


def _suggested_regressions(risks: list[RiskFinding]) -> list[SuggestedRegression]:
    seen: set[tuple[str, str, str]] = set()
    out: list[SuggestedRegression] = []
    for risk in risks:
        key = (risk.surface_type, risk.surface_id, risk.risk)
        if key in seen:
            continue
        seen.add(key)
        out.append(SuggestedRegression(
            surface_type=risk.surface_type,
            surface_id=risk.surface_id,
            name=f"launch_review_{_safe_id(risk.surface_id)}_{_safe_id(risk.risk)}",
            expected_status="blocked",
            scenario_hint=risk.risk,
        ))
    return out


def _items_by_id(value: Any, surface_type: str) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    if not isinstance(value, list):
        return out
    for idx, item in enumerate(value):
        props = dict(item) if isinstance(item, Mapping) else {"value": item}
        sid = _surface_id(props, idx)
        if sid in out:
            raise ProductModelError(
                f"{surface_type} contains duplicate modeled surface id: {sid}"
            )
        out[sid] = _ordered(props)
    return out


def _surface_id(props: Mapping[str, Any], idx: int) -> str:
    for key in ("id", "name", "route", "path", "tool", "connector", "role", "plan", "event", "action"):
        if props.get(key):
            return str(props[key])
    if "value" in props:
        return str(props["value"])
    return str(idx)


def _first(props: Mapping[str, Any], *names: str) -> Any:
    for name in names:
        if name in props:
            return props[name]
    return None


def _bad_control(value: Any) -> bool:
    if value is False:
        return True
    if isinstance(value, str):
        return value.strip().lower() in _MISSING_VALUES
    return False


def _truthy(value: Any) -> bool:
    if value is True:
        return True
    if isinstance(value, (int, float)) and value:
        return True
    if isinstance(value, str):
        return value.strip().lower() in {"true", "yes", "on", "enabled", "billable", "metered", "paid"}
    return False


def _reachable(props: Mapping[str, Any]) -> bool:
    if props.get("reachable") is False:
        return False
    if _truthy(props.get("reachable")):
        return True
    plan = str(_first(props, "reachable_by_plan", "granted_plan", "current_plan") or "").lower()
    role = str(_first(props, "reachable_by_role", "installable_by_role", "granted_role") or "").lower()
    return plan in _LOW_REACH_PLANS or role in {"anonymous", "member", "user", "anyone"}


def _number(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _to_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        return [str(v) for v in value]
    if isinstance(value, str) and "," in value:
        return [v.strip() for v in value.split(",") if v.strip()]
    return [str(value)]


def _scope_wider(granted: str, intended: str) -> bool:
    return (
        _SCOPE_RANK.get(granted, 0) > _SCOPE_RANK.get(intended, 0)
        or is_broad_scope(granted) and granted != intended
    )


def _text(props: Mapping[str, Any], *names: str) -> str:
    return " ".join(str(props.get(n, "")) for n in names).lower()


def _ordered(props: Mapping[str, Any]) -> dict[str, Any]:
    return {k: props[k] for k in sorted(props)}


def _stable_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def _safe_id(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in "._:-" else "_" for ch in value).strip("_")[:80] or "surface"
