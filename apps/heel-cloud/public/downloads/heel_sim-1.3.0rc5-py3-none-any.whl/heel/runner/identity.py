"""Runner-local identity primitives.

Private material intentionally stays behind :class:`SecureSigner`; this module only
ever moves a public key and signatures across the runner/control-plane boundary.
"""
from __future__ import annotations

import base64
import hashlib
import os
import re
import secrets
import stat
import subprocess
import threading
import unicodedata
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Callable, Mapping, Protocol, Sequence

from heel.crypto import ed25519_key_id


RUNNER_CAPABILITIES = (
    "runner_claim", "runner_heartbeat", "runner_progress", "runner_result",
)
_MACOS_SECURITY_PATH = "/usr/bin/security"
_LINUX_SECRET_TOOL_PATH = "/usr/bin/secret-tool"
_LINUX_SECRET_TOOL_ALLOWLIST = frozenset({_LINUX_SECRET_TOOL_PATH})
_SECRET_HELPER_TIMEOUT_SECONDS = 5
_HELPER_BASE_ENV = (("PATH", "/usr/bin:/bin"), ("LC_ALL", "C"))
_SESSION_BUS_VARIABLE = "DBUS_SESSION_BUS_ADDRESS"
_MAX_SESSION_BUS_ADDRESS_BYTES = 1024
# D-Bus "optionally escaped" bytes minus ``*``: ``%`` escapes, ``;`` lists, ``,``/``=`` and every
# other byte are refused, so the accepted value needs no unescaping and re-serialises exactly.
_SESSION_BUS_PATH = re.compile(r"^/[-0-9A-Za-z_/.]{1,1022}$", flags=re.ASCII)
_SESSION_BUS_GUID = re.compile(r"^[0-9a-f]{32}$", flags=re.ASCII)
_MAX_SECRET_HELPER_OUTPUT_BYTES = 1024
# One OS secret-store account per local pairing installation; never derived from a secret.
RUNNER_PAIRING_SIGNER_LABEL_PREFIX = "heel-runner-pairing-v1-"


def _phrase_words() -> tuple[str, ...]:
    """Return Heel's stable public 2,048-word pairing vocabulary.

    This is intentionally generated rather than read from a private server module: a local
    runner must be able to validate the phrase it displays without receiving any cloud secret.
    """
    onset = ("b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "r", "s", "t", "v",
             "w", "z", "br", "cl", "dr", "fr", "gr", "kr", "pl", "pr", "sk", "sl", "st", "tr", "vr", "zl")
    vowel = ("a", "e", "i", "o", "u", "ae", "ai", "ao", "ea", "ei", "ia", "io", "oa", "oi", "ua", "ui")
    tail = ("n", "r", "l", "m")
    return tuple(a + b + c for a in onset for b in vowel for c in tail)


_RUNNER_PHRASE_WORDS = _phrase_words()


def runner_phrase_words() -> tuple[str, ...]:
    """The immutable public vocabulary used by every pairing surface."""
    return _RUNNER_PHRASE_WORDS


def validate_pairing_phrase(value: object) -> str:
    if type(value) is not str or value != value.lower() or value != " ".join(value.split()):
        raise ValueError("invalid pairing phrase")
    words = value.split(" ")
    if len(words) != 6 or any(word not in _RUNNER_PHRASE_WORDS for word in words):
        raise ValueError("invalid pairing phrase")
    return value


def runner_pairing_signer_label(installation_id: str) -> str:
    """Return the OS secret-store label for one random 32-hex local pairing installation."""
    if (
        type(installation_id) is not str or len(installation_id) != 32
        or any(char not in "0123456789abcdef" for char in installation_id)
    ):
        raise ValueError("invalid runner pairing installation ID")
    return RUNNER_PAIRING_SIGNER_LABEL_PREFIX + installation_id


class SecureSigner:
    """Minimal key-store interface; implementations must not expose a private seed."""

    # Attributes (rather than abstract @properties) keep key-store test doubles simple while
    # still documenting the deliberately tiny interface.
    key_id: str
    public_key: bytes

    def sign(self, payload: bytes) -> bytes:
        raise NotImplementedError


class OSSecretBackend(Protocol):
    """Private key seed storage boundary. It deliberately has no list/export operation."""

    def load(self, label: str) -> bytes | None: ...
    def store(self, label: str, seed: bytes) -> None: ...


class InMemorySecretBackend:
    """Explicit test-only backend; production callers must inject an OS-backed implementation."""

    def __init__(self):
        self._values: dict[str, bytes] = {}

    def load(self, label: str) -> bytes | None:
        value = self._values.get(label)
        return None if value is None else bytes(value)

    def store(self, label: str, seed: bytes) -> None:
        if label in self._values:
            raise ValueError("runner signing identity already exists")
        self._values[label] = bytes(seed)


class _CommandSecretBackend:
    """Shared validation for OS secret-service record labels."""

    @staticmethod
    def _label(label: str) -> str:
        if type(label) is not str or not label or len(label) > 128 or "\x00" in label:
            raise ValueError("invalid runner signing label")
        return label


def _verified_secret_helper_path(path: str) -> str:
    """Return an allowlisted helper only when it is an absolute regular executable."""
    if not os.path.isabs(path) or os.path.normpath(path) != path:
        raise RuntimeError("runner OS secret service unavailable")
    try:
        status = os.stat(path, follow_symlinks=False)
    except OSError:
        raise RuntimeError("runner OS secret service unavailable") from None
    if not stat.S_ISREG(status.st_mode) or not os.access(path, os.X_OK):
        raise RuntimeError("runner OS secret service unavailable")
    return path


def _verified_security_path() -> str:
    """Return the one fixed macOS helper only when it is a regular executable."""
    return _verified_secret_helper_path(_MACOS_SECURITY_PATH)


def _verified_secret_tool_path() -> str:
    """Return the one fixed Linux helper only when it is a regular executable."""
    if _LINUX_SECRET_TOOL_PATH not in _LINUX_SECRET_TOOL_ALLOWLIST:
        raise RuntimeError("runner OS secret service unavailable")
    return _verified_secret_helper_path(_LINUX_SECRET_TOOL_PATH)


def session_bus_address() -> str:
    """Return the canonical local session-bus address, or fail closed without echoing it.

    Accepted: exactly one ``unix:`` entry with closed, non-duplicated keys ``path`` (required)
    and ``guid`` (optional, 32 lowercase hex); ``path`` is absolute, normalised and names an
    existing AF_UNIX socket (not a symlink) owned by the current uid. Unset, remote, list,
    abstract, ``tmpdir``/``runtime``, ``unixexec``, ``autolaunch`` and escaped values are refused.
    """
    unavailable = "runner OS secret service unavailable"
    value = os.environ.get(_SESSION_BUS_VARIABLE)
    if (
        type(value) is not str or not value.isascii()
        or not 0 < len(value) <= _MAX_SESSION_BUS_ADDRESS_BYTES
        or not value.startswith("unix:")
    ):
        raise RuntimeError(unavailable)
    fields: dict[str, str] = {}
    for pair in value[len("unix:"):].split(","):
        key, separator, item = pair.partition("=")
        if not separator or key not in {"path", "guid"} or key in fields:
            raise RuntimeError(unavailable)
        fields[key] = item
    path, guid = fields.get("path"), fields.get("guid")
    if (
        path is None or _SESSION_BUS_PATH.fullmatch(path) is None
        or os.path.normpath(path) != path
        or (guid is not None and _SESSION_BUS_GUID.fullmatch(guid) is None)
    ):
        raise RuntimeError(unavailable)
    try:
        status = os.lstat(path)
    except (OSError, ValueError):
        raise RuntimeError(unavailable) from None
    if not stat.S_ISSOCK(status.st_mode) or status.st_uid != os.getuid():
        raise RuntimeError(unavailable)
    return f"unix:path={path}" + ("" if guid is None else f",guid={guid}")


def secret_tool_environment() -> dict[str, str]:
    """The complete ``secret-tool`` environment: no other variable is ever forwarded."""
    return {**dict(_HELPER_BASE_ENV), _SESSION_BUS_VARIABLE: session_bus_address()}


def _run_bounded_secret_helper(
    helper: str, arguments: tuple[str, ...], *, payload: bytes | None,
    popen: Callable[..., object], env: Mapping[str, str] | None = None,
) -> subprocess.CompletedProcess:
    """Run a fixed OS secret helper with bounded capture and stdin-only secret input."""
    argv = (helper, *arguments)
    environment = dict(_HELPER_BASE_ENV) if env is None else dict(env)
    try:
        process = popen(
            argv,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            shell=False,
            bufsize=0,
            env=environment,
        )
        process_stdin = process.stdin
        process_stdout = process.stdout
    except (AttributeError, OSError, TypeError, ValueError):
        raise RuntimeError("runner OS secret service unavailable") from None
    if process_stdin is None or process_stdout is None:
        try:
            process.kill()
            process.wait()
        except (AttributeError, OSError, subprocess.SubprocessError):
            pass
        raise RuntimeError("runner OS secret service unavailable")

    retained = bytearray()
    worker_failed = threading.Event()

    def write_input() -> None:
        try:
            if payload is not None:
                process_stdin.write(payload)
                process_stdin.flush()
        except (BrokenPipeError, OSError, TypeError, ValueError):
            worker_failed.set()
        finally:
            try:
                process_stdin.close()
            except (OSError, ValueError):
                pass

    def read_output() -> None:
        try:
            while True:
                chunk = process_stdout.read(4096)
                if not chunk:
                    return
                remaining = _MAX_SECRET_HELPER_OUTPUT_BYTES + 1 - len(retained)
                if remaining > 0:
                    retained.extend(chunk[:remaining])
        except (OSError, TypeError, ValueError):
            worker_failed.set()

    writer = threading.Thread(target=write_input, daemon=True)
    reader = threading.Thread(target=read_output, daemon=True)
    writer.start()
    reader.start()
    try:
        returncode = process.wait(timeout=_SECRET_HELPER_TIMEOUT_SECONDS)
    except (OSError, TypeError, ValueError, subprocess.SubprocessError):
        try:
            process.kill()
            process.wait()
        except (AttributeError, OSError, subprocess.SubprocessError):
            pass
        raise RuntimeError("runner OS secret service unavailable") from None
    finally:
        writer.join(1)
        reader.join(1)
        try:
            process_stdout.close()
        except (OSError, ValueError):
            pass
    if writer.is_alive() or reader.is_alive() or worker_failed.is_set():
        try:
            process.kill()
            process.wait()
        except (AttributeError, OSError, subprocess.SubprocessError):
            pass
        raise RuntimeError("runner OS secret service unavailable")
    return subprocess.CompletedProcess(argv, returncode, bytes(retained), None)


# ``security add-generic-password -w`` without a value prompts twice and reads stdin line-wise
# through a 128-byte password buffer: one value on stdin stores an EMPTY item with exit 0, and a
# longer value is silently truncated. ``security -i`` (documented interactive mode) instead reads
# one command per stdin line, so the value never reaches argv. Its line buffer is about 4 KiB: a
# longer line is cut, stores a truncated value and the rest is parsed as further commands. Every
# token is therefore restricted to a tokenizer-inert alphabet and the line is length-capped here.
_SECURITY_INTERACTIVE_TOKEN = re.compile(r"^(?!-)[A-Za-z0-9+/=_.:-]{1,3200}$", flags=re.ASCII)
SECURITY_INTERACTIVE_MAX_LINE_BYTES = 3584


def security_interactive_add_command(service: str, account: str, value: bytes) -> bytes:
    """Return one ``security -i`` stdin line that adds a generic password without ``-U``."""
    tokens = (service, account, value.decode("ascii") if isinstance(value, bytes) else value)
    if any(type(token) is not str or _SECURITY_INTERACTIVE_TOKEN.fullmatch(token) is None for token in tokens):
        raise ValueError("invalid keychain command token")
    line = f"add-generic-password -s {tokens[0]} -a {tokens[1]} -w {tokens[2]}\n".encode("ascii")
    if len(line) > SECURITY_INTERACTIVE_MAX_LINE_BYTES:
        raise ValueError("keychain command exceeds the interactive line limit")
    return line


def _run_bounded_security(
    arguments: tuple[str, ...], *, payload: bytes | None, popen: Callable[..., object],
) -> subprocess.CompletedProcess:
    return _run_bounded_secret_helper(
        _verified_security_path(), arguments, payload=payload, popen=popen,
    )


def _run_bounded_secret_tool(
    arguments: tuple[str, ...], *, payload: bytes | None, popen: Callable[..., object],
) -> subprocess.CompletedProcess:
    helper = _verified_secret_tool_path()
    # Validated before any process exists and before any payload is written.
    environment = secret_tool_environment()
    return _run_bounded_secret_helper(
        helper, arguments, payload=payload, popen=popen, env=environment,
    )


class MacOSKeychainSecretBackend:
    """macOS Keychain adapter. Errors intentionally look like key-store failure, never data."""

    service = "heel.runner.ed25519.v1"

    def __init__(self, *, popen: Callable[..., object] = subprocess.Popen):
        self._popen = popen

    @staticmethod
    def _label(label: str) -> str:
        return _CommandSecretBackend._label(label)

    def load(self, label: str) -> bytes | None:
        label = self._label(label)
        result = _run_bounded_security(
            ("find-generic-password", "-s", self.service, "-a", label, "-w"),
            payload=None,
            popen=self._popen,
        )
        if result.returncode == 44:
            return None
        if result.returncode != 0:
            raise RuntimeError("runner OS secret service unavailable")
        try:
            seed = base64.b64decode(result.stdout.strip(), validate=True)
        except (TypeError, ValueError):
            raise RuntimeError("runner OS secret service returned invalid material") from None
        if len(seed) != 32:
            # Includes the empty items earlier releases stored; they are reported, never rewritten.
            raise RuntimeError("runner OS secret service returned invalid material")
        return seed

    def store(self, label: str, seed: bytes) -> None:
        label = self._label(label)
        if not isinstance(seed, bytes) or len(seed) != 32:
            raise RuntimeError("runner OS secret service returned invalid material")
        try:
            command = security_interactive_add_command(self.service, label, base64.b64encode(seed))
        except ValueError:
            raise ValueError("invalid runner signing label") from None
        result = _run_bounded_security(("-i",), payload=command, popen=self._popen)
        if result.returncode != 0:
            raise RuntimeError("runner OS secret service unavailable")
        # Exit 0 created this item; keep it only when it reads back as exactly this seed.
        try:
            stored = self.load(label)
        except RuntimeError:
            stored = None
        if stored != seed:
            try:
                self.delete(label)
            except RuntimeError:
                pass
            raise RuntimeError("runner OS secret service unavailable")

    def delete(self, label: str) -> None:
        """Remove one item; a missing item is already removed."""
        result = _run_bounded_security(
            ("delete-generic-password", "-s", self.service, "-a", self._label(label)),
            payload=None,
            popen=self._popen,
        )
        if result.returncode not in (0, 44):
            raise RuntimeError("runner OS secret service unavailable")


class LinuxSecretServiceBackend:
    """Freedesktop Secret Service adapter via ``secret-tool`` (no filesystem fallback)."""

    def __init__(self, *, popen: Callable[..., object] = subprocess.Popen):
        self._popen = popen

    @staticmethod
    def _label(label: str) -> str:
        return _CommandSecretBackend._label(label)

    def load(self, label: str) -> bytes | None:
        label = self._label(label)
        result = _run_bounded_secret_tool(
            ("lookup", "heel", "runner", "label", label),
            payload=None,
            popen=self._popen,
        )
        if result.returncode == 1:
            # lookup exit 1 means missing, unreachable or locked. A search for the item's own
            # attributes lists a locked item too, so only exit 0 with no output is "missing";
            # a locked existing item is unavailable and can never be overwritten by store.
            if self._absent(label):
                return None
            raise RuntimeError("runner OS secret service unavailable")
        if result.returncode != 0:
            raise RuntimeError("runner OS secret service unavailable")
        try:
            return base64.b64decode(result.stdout.strip(), validate=True)
        except (TypeError, ValueError):
            raise RuntimeError("runner OS secret service returned invalid material") from None

    def _absent(self, label: str) -> bool:
        """``search`` for the item's own attributes exits 0 only when the service answered and
        lists locked items too: exit 0 with no output is the only "missing". Any output (which
        may hold the secret if the item unlocked meanwhile) stays in the bounded capture and is
        discarded, never returned or logged."""
        result = _run_bounded_secret_tool(
            ("search", "heel", "runner", "label", label), payload=None, popen=self._popen,
        )
        return result.returncode == 0 and result.stdout == b""

    def store(self, label: str, seed: bytes) -> None:
        label = self._label(label)
        if not isinstance(seed, bytes) or len(seed) != 32:
            raise RuntimeError("runner OS secret service returned invalid material")
        result = _run_bounded_secret_tool(
            ("store", "--label=Heel runner signing key", "heel", "runner", "label", label),
            payload=base64.b64encode(seed),
            popen=self._popen,
        )
        if result.returncode != 0:
            raise RuntimeError("runner OS secret service unavailable")


class SystemSecureSigner(SecureSigner):
    """Ed25519 signer whose seed is generated and kept in an injected OS secret backend."""

    def __init__(self, label: str, *, backend: OSSecretBackend | None = None):
        backend = self._backend(backend)
        label = self._label(label)
        seed = backend.load(label)
        if seed is None:
            seed = secrets.token_bytes(32)
            backend.store(label, seed)
        self._initialize_seed(seed)

    @staticmethod
    def _backend(backend: OSSecretBackend | None) -> OSSecretBackend:
        if backend is None:
            if os.name == "posix" and __import__("platform").system() == "Darwin":
                backend = MacOSKeychainSecretBackend()
            elif os.name == "posix":
                backend = LinuxSecretServiceBackend()
            else:
                raise RuntimeError("no supported runner OS secret service")
        if isinstance(backend, InMemorySecretBackend) and os.environ.get("PYTEST_CURRENT_TEST") is None:
            raise RuntimeError("in-memory runner secret backend is test-only")
        return backend

    @staticmethod
    def _label(label: str) -> str:
        if type(label) is not str or not label or len(label) > 128 or "\x00" in label:
            raise ValueError("invalid runner signing label")
        return label

    def _initialize_seed(self, seed: bytes) -> None:
        if not isinstance(seed, bytes) or len(seed) != 32:
            raise RuntimeError("runner OS secret service returned invalid material")
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
        self._private = Ed25519PrivateKey.from_private_bytes(seed)
        self.public_key = self._private.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
        self.key_id = ed25519_key_id(self.public_key)

    @classmethod
    def create_new(cls, label: str, *, backend: OSSecretBackend | None = None) -> "SystemSecureSigner":
        """Create a replacement signer once; recovery must use :meth:`load_existing`."""
        backend = cls._backend(backend)
        label = cls._label(label)
        if backend.load(label) is not None:
            raise ValueError("runner signing identity already exists")
        seed = secrets.token_bytes(32)
        if type(seed) is not bytes or len(seed) != 32:
            raise RuntimeError("runner OS secret service returned invalid material")
        backend.store(label, seed)
        instance = cls.__new__(cls)
        instance._initialize_seed(seed)
        return instance

    @classmethod
    def load_existing(cls, label: str, *, backend: OSSecretBackend | None = None) -> "SystemSecureSigner":
        """Load a named signer without ever generating one during recovery."""
        backend = cls._backend(backend)
        seed = backend.load(cls._label(label))
        if seed is None:
            raise RuntimeError("runner signing identity is unavailable")
        instance = cls.__new__(cls)
        instance._initialize_seed(seed)
        return instance

    def sign(self, payload: bytes) -> bytes:
        if not isinstance(payload, bytes):
            raise TypeError("runner signing payload must be bytes")
        return self._private.sign(payload)

    def __repr__(self) -> str:
        return f"SystemSecureSigner(key_id={self.key_id!r})"


@dataclass(frozen=True, repr=False)
class RunnerIdentity:
    runner_id: str
    workspace_id: str
    runner_version: str
    adapter_versions: dict[str, str]
    public_key_b64: str
    fingerprint: str
    key_id: str
    pairing_phrase: tuple[str, ...]
    capabilities: tuple[str, ...] = RUNNER_CAPABILITIES

    def __repr__(self) -> str:
        return (
            "RunnerIdentity(runner_id={!r}, workspace_id={!r}, key_id={!r}, "
            "fingerprint={!r})"
        ).format(self.runner_id, self.workspace_id, self.key_id, self.fingerprint)


@dataclass(frozen=True, repr=False)
class PendingPairingActivation:
    """One exact v3 activation request backed by a signed local prepared journal."""

    pending: Mapping[str, object]
    request: Mapping[str, object]
    challenge_expires_at_ms: int | None
    _material: object = field(repr=False, compare=False)


@dataclass(frozen=True, repr=False)
class PendingPairingActivationAbort:
    """One Store-minted, byte-exact pairing abort request capability."""

    pairing_id: str
    runner_id: str
    request: Mapping[str, object]
    challenge_expires_at_ms: int | None
    _pending: PendingPairingActivation = field(repr=False, compare=False)
    _journal_digest: str = field(repr=False, compare=False)
    _store_token: object = field(repr=False, compare=False)

    def __post_init__(self) -> None:
        # The Store passes a fresh closed dictionary.  Detach it again at this
        # boundary so neither a transport nor caller can mutate signed bytes.
        object.__setattr__(self, "request", MappingProxyType(dict(self.request)))

    def __reduce_ex__(self, protocol: int) -> object:
        del protocol
        raise TypeError("pending pairing activation abort cannot be serialized")


@dataclass(frozen=True, repr=False)
class PendingRotationActivation:
    """Live-only rotation request capability; the replacement signer is never serialized."""

    pending: Mapping[str, object]
    request: Mapping[str, object]
    old_identity: RunnerIdentity
    new_identity: RunnerIdentity
    new_signer_label: str
    _new_signer: SecureSigner = field(repr=False, compare=False)
    _store_token: object = field(repr=False, compare=False)
    _eligibility: object = field(repr=False, compare=False)

    def __reduce_ex__(self, protocol: int) -> object:
        del protocol
        raise TypeError("pending runner rotation activation cannot be serialized")


@dataclass(frozen=True, repr=False)
class AcceptedRotationJournal:
    """Validated public rotation journal data consumed by the sealed runtime transition."""

    pairing_id: str
    old_identity: RunnerIdentity
    new_identity: RunnerIdentity
    activation_challenge: str
    activation_request: Mapping[str, object]
    activation_response: Mapping[str, object]
    created_at_ms: int
    updated_at_ms: int
    new_signer_label: str
    prepared_journal_digest: str
    runtime_rotation_intent_digest: str


@dataclass(frozen=True, repr=False)
class AcceptedRotationAbortTombstone:
    """Validated local proof that the Cloud atomically aborted a prepared rotation."""

    pairing_id: str
    old_identity: RunnerIdentity
    new_identity: RunnerIdentity
    prepared_journal_digest: str
    runtime_rotation_intent_digest: str
    record: Mapping[str, object]


@dataclass(frozen=True, repr=False)
class RunnerPairingMaterial:
    """Public pairing payload prepared before the cloud allocates a runner ID.

    The signer remains an opaque local capability; callers can display and send the
    public fields, but cannot derive or export its private material.
    """

    display_name: str
    runner_version: str
    adapters: dict[str, str]
    public_key_b64: str
    fingerprint: str
    key_id: str
    pairing_phrase: tuple[str, ...]
    _signer: SecureSigner

    def exchange_request(self, invitation_token: str) -> dict[str, object]:
        if type(invitation_token) is not str or not invitation_token:
            raise ValueError("invitation token is required")
        return {
            "schema_version": "heel.runner-pairing-exchange.v2",
            "invitation_token": invitation_token,
            "public_key_b64": self.public_key_b64,
            "pairing_phrase": " ".join(self.pairing_phrase),
            "display_name": self.display_name,
            "runner_version": self.runner_version,
            "adapters": dict(self.adapters),
        }

    def executable_exchange_request(self, invitation_token: str) -> dict[str, object]:
        """Build the v3 exchange that opts this material into the executable protocol."""
        request = self.exchange_request(invitation_token)
        request["schema_version"] = "heel.runner-pairing-exchange.v3"
        request["control_protocol"] = "heel.runner-control.v2"
        return request

    def prepare_executable_activation(
        self, pending_v2: Mapping[str, object], *, store: Any, now_ms: int,
        random_source: Callable[[int], bytes] = secrets.token_bytes,
    ) -> PendingPairingActivation:
        """Durably prepare the one signed v3 activation request before transport."""
        prepare = getattr(store, "_prepare_pairing_activation", None)
        if not callable(prepare):
            raise ValueError("runner pairing activation store is required")
        return prepare(self, pending_v2, now_ms=now_ms, random_source=random_source)


def _display_name(value: object) -> str:
    if type(value) is not str:
        raise ValueError("runner display name is required")
    normalized = unicodedata.normalize("NFC", value)
    if (not 1 <= len(normalized) <= 64 or len(normalized.encode("utf-8")) > 128
            or normalized != normalized.strip()
            or any(unicodedata.category(char) == "Cc" or 0xD800 <= ord(char) <= 0xDFFF
                   for char in normalized)):
        raise ValueError("invalid runner display name")
    return normalized


def create_runner_pairing_material(
    display_name: str,
    runner_version: str,
    adapters: dict[str, str],
    signer: SecureSigner,
    *,
    words: Sequence[str] | None = None,
    random_source: Callable[[int], bytes] = secrets.token_bytes,
) -> RunnerPairingMaterial:
    """Prepare v2 exchange material before the control plane allocates ``runner_id``."""
    display_name = _display_name(display_name)
    if type(runner_version) is not str or not runner_version:
        raise ValueError("runner version is required")
    if not isinstance(adapters, dict) or not all(type(k) is str and k and type(v) is str and v
                                                 for k, v in adapters.items()):
        raise ValueError("adapters must be a string map")
    vocabulary = _validate_words(runner_phrase_words() if words is None else words)
    public_key = signer.public_key
    if not isinstance(public_key, bytes) or len(public_key) != 32:
        raise ValueError("runner signer must expose a 32-byte Ed25519 public key")
    key_id = ed25519_key_id(public_key)
    if signer.key_id != key_id:
        raise ValueError("runner signer key ID does not match its public key")
    entropy = random_source(12)
    if not isinstance(entropy, bytes) or len(entropy) != 12:
        raise ValueError("runner random source must return exactly requested bytes")
    phrase = tuple(vocabulary[int.from_bytes(entropy[index:index + 2], "big") % 2048]
                   for index in range(0, 12, 2))
    return RunnerPairingMaterial(
        display_name=display_name, runner_version=runner_version, adapters=dict(sorted(adapters.items())),
        public_key_b64=base64.b64encode(public_key).decode("ascii"),
        fingerprint=hashlib.sha256(public_key).hexdigest(), key_id=key_id,
        pairing_phrase=phrase, _signer=signer,
    )


def bind_runner_identity(material: RunnerPairingMaterial, *, workspace_id: str, runner_id: str) -> RunnerIdentity:
    """Bind server-issued identity coordinates only after successful activation."""
    if not isinstance(material, RunnerPairingMaterial):
        raise ValueError("runner pairing material is required")
    if not all(type(item) is str and item for item in (workspace_id, runner_id)):
        raise ValueError("runner identity fields must be non-empty strings")
    return RunnerIdentity(
        runner_id=runner_id, workspace_id=workspace_id, runner_version=material.runner_version,
        adapter_versions=dict(material.adapters), public_key_b64=material.public_key_b64,
        fingerprint=material.fingerprint, key_id=material.key_id,
        pairing_phrase=material.pairing_phrase,
    )


def _validate_words(words: Sequence[str]) -> tuple[str, ...]:
    values = tuple(words)
    if len(values) != 2048:
        raise ValueError("runner phrase word list must contain exactly 2048 words")
    if len(set(values)) != len(values):
        raise ValueError("runner phrase word list must contain unique words")
    if any(type(word) is not str or not word or word != word.lower() or " " in word for word in values):
        raise ValueError("runner phrase words must be lowercase non-empty atoms")
    return values


def create_runner_identity(
    runner_id: str,
    workspace_id: str,
    runner_version: str,
    adapter_versions: dict[str, str],
    signer: SecureSigner,
    words: Sequence[str],
    random_source: Callable[[int], bytes],
) -> RunnerIdentity:
    """Create public pairing material and a six-word (66-bit) human comparison cue."""
    if not all(type(item) is str and item for item in (runner_id, workspace_id, runner_version)):
        raise ValueError("runner identity fields must be non-empty strings")
    if not isinstance(adapter_versions, dict) or not all(
        type(key) is str and type(value) is str for key, value in adapter_versions.items()
    ):
        raise ValueError("adapter versions must be a string map")
    vocabulary = _validate_words(words)
    public_key = signer.public_key
    if not isinstance(public_key, bytes) or len(public_key) != 32:
        raise ValueError("runner signer must expose a 32-byte Ed25519 public key")
    key_id = ed25519_key_id(public_key)
    if signer.key_id != key_id:
        raise ValueError("runner signer key ID does not match its public key")
    entropy = random_source(12)
    if not isinstance(entropy, bytes) or len(entropy) != 12:
        raise ValueError("runner random source must return exactly requested bytes")
    phrase = tuple(vocabulary[int.from_bytes(entropy[index:index + 2], "big") % 2048]
                   for index in range(0, 12, 2))
    return RunnerIdentity(
        runner_id=runner_id,
        workspace_id=workspace_id,
        runner_version=runner_version,
        adapter_versions=dict(adapter_versions),
        public_key_b64=base64.b64encode(public_key).decode("ascii"),
        fingerprint=hashlib.sha256(public_key).hexdigest(),
        key_id=key_id,
        pairing_phrase=phrase,
    )
