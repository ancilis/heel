"""Bounded, deterministic execution of an exact customer-local canary grant."""
from __future__ import annotations

import base64
from collections.abc import Callable, Mapping
import copy
from dataclasses import dataclass
import hashlib
import json
import threading
import time
from typing import Any

from heel.canary_contracts import (
    CANARY_FINDINGS_SCHEMA,
    CONFIGURED_FINDINGS_SCHEMA,
    CONFIGURED_ROLE_ORDER,
    CONFIGURED_TEST_MANIFEST_SCHEMA,
    configured_projection_instance,
    validate_configured_findings,
    validate_runner_approval_projection,
    validate_runner_test_manifest,
    OPERATIONAL_RUN_SCHEMA,
    canonical_bytes,
    canonical_digest,
    validate_approval_projection,
    validate_canary_findings,
    validate_execution_grant,
    validate_operational_run,
    validate_test_manifest,
)
from heel.crypto import verify_envelope
from heel.runner.adapters import evaluate_pair, prepare_action
from heel.runner.content_assertion import (
    LiveReadResponse,
    evaluate_live_read_pair,
    protected_content,
    resolve_local_fixtures,
    validate_live_read_assertion,
)
from heel.runner.companion import validate_disclosure_preview, validate_local_result_view
from heel.runner.containment import ContainmentLog, operational_containment_codes
from heel.runner.http_transport import (
    AttemptPermit,
    BoundedResponseEvidence,
    CancellationToken,
    EvidenceContext,
    RetryPolicy,
    TransportFailure,
)
from heel.runner.identity import RunnerIdentity, SecureSigner
from heel.runner.redaction import Redactor
from heel.runner.store import (
    LiveInputUnavailable, RunReservationProbe, RunnerStore, RunnerStoreError,
)
from heel.runner.vault import EphemeralVault, VaultUnavailable, validate_credential_secret


_PLAN_SCENARIO = "plan_entitlement_read"


_UNRESOLVED = object()


def _configured(manifest: Mapping[str, Any]) -> bool:
    return manifest["schema_version"] == CONFIGURED_TEST_MANIFEST_SCHEMA


def _units(manifest: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    """Result units: configured test instances, or catalog scenarios for v1."""
    return manifest["test_instances"] if _configured(manifest) else manifest["scenarios"]


def _unit_key(record: Mapping[str, Any]) -> str:
    return record.get("test_instance_id", record["scenario_id"])


def _catalog_action(action: Mapping[str, Any]) -> dict[str, Any]:
    """The exact closed v1 action the launch adapter prepares; instance identity stays signed."""
    return {key: value for key, value in action.items() if key != "test_instance_id"}


def _configured_finding() -> dict[str, str]:
    return {
        "title": "Configured live condition held for the restricted role",
        "reachability_rationale": (
            "On this approved read, the restricted role's response satisfied the frozen "
            "configured condition, and the control role's response satisfied the success "
            "witness and the same condition. Only the configured field was evaluated; no "
            "value is reported. Only this read was tested."
        ),
        "confidence": "medium",
        "recommended_control": "Enforce the selected authorization boundary on this read.",
        "regression_suggestion": "Replay this exact configured instance with a new one-shot grant.",
    }


def _plan_differential_finding() -> dict[str, str]:
    """Finding copy for a markerless row-6 result: key-path coverage, never equal values."""
    from heel.runner.plan_differential import _RECOMMENDED_CONTROL

    return {
        "title": "Lower-plan read covered every key path of the higher-plan response",
        "reachability_rationale": (
            "On the same approved read, the lower-plan identity's response contained every "
            "key path of the higher-plan identity's response, populated wherever the "
            "higher-plan response was populated, and the higher-plan control succeeded. Key "
            "paths were compared; values were not compared and no marker was bound. Heel "
            "holds no declaration that this read is plan-gated, so a read that is not "
            "plan-gated by design is reported too. Only this read was tested."
        ),
        "confidence": "medium",
        "recommended_control": _RECOMMENDED_CONTROL,
        "regression_suggestion": "Repeat this exact catalog scenario with a new one-shot grant.",
    }


@dataclass(frozen=True, slots=True)
class ExecutionGate:
    active: bool
    runner_state: str
    proof_state: str
    proof_expires_at_ms: int
    kill_switch_generation: int
    stop_reason: str
    server_time_ms: int

    def __post_init__(self) -> None:
        if type(self.active) is not bool:
            raise ValueError("execution gate active flag must be boolean")
        if self.runner_state not in {"active", "revoked", "replaced"}:
            raise ValueError("invalid execution gate runner state")
        if self.proof_state not in {"valid", "expired", "revoked"}:
            raise ValueError("invalid execution gate proof state")
        if self.stop_reason not in {
            "none", "local_emergency_stop", "cloud_stop", "runner_revoked",
            "target_revoked", "kill_switch",
        }:
            raise ValueError("invalid execution gate stop reason")
        for name in ("proof_expires_at_ms", "kill_switch_generation", "server_time_ms"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError("invalid execution gate timestamp or generation")


class _SerializedContainmentLog:
    """Serialize the executor and stop worker onto one append-only local event chain."""

    def __init__(self, delegate: ContainmentLog):
        self._delegate = delegate
        self._lock = threading.Lock()

    def load(self) -> list[dict[str, Any]]:
        with self._lock:
            return self._delegate.load()

    def append(self, *args, **kwargs) -> dict[str, Any]:
        with self._lock:
            return self._delegate.append(*args, **kwargs)


@dataclass(frozen=True, slots=True)
class ExecutionBundle:
    manifest: Mapping[str, Any]
    projection: Mapping[str, Any]
    grant: Mapping[str, Any]


@dataclass(frozen=True, slots=True)
class ValidatedExecutionBundle:
    manifest: dict[str, Any]
    projection: dict[str, Any]
    grant: dict[str, Any]


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    assessment_outcome: str
    execution_disposition: str
    operational_projection: dict[str, Any]
    findings_projection: dict[str, Any]
    local_view: dict[str, Any]
    disclosure_preview: dict[str, Any]


@dataclass(frozen=True, slots=True)
class UnactivatedExecution:
    """A stop was known before local activation: nothing was reserved, loaded or dialed.

    There is no local receipt to acknowledge or report; the Cloud stop lifecycle owns the run.
    """

    stop_reason: str
    operational_projection: None = None


class LocalRunNotActive(RunnerStoreError):
    """No locally activated run matches a stop acknowledgement request."""


_MAX_GATE_STALE_SECONDS = 0.5


class _LiveAuthority:
    """Monotonic, non-renewable authority derived from the first server clock sample."""

    def __init__(
        self,
        *,
        grant: Mapping[str, Any],
        initial_gate: ExecutionGate,
        now: float,
    ):
        self._grant = grant
        self._lock = threading.Lock()
        self._last_server_time_ms = initial_gate.server_time_ms
        self._last_advance = now
        self._grant_deadline = now + (
            grant["expires_at_ms"] - initial_gate.server_time_ms
        ) / 1000
        self._proof_deadline = now + (
            initial_gate.proof_expires_at_ms - initial_gate.server_time_ms
        ) / 1000

    @staticmethod
    def _rejected(error: str, stop: str = "none") -> TransportFailure:
        failure = TransportFailure("cancelled" if stop != "none" else "gate_rejected")
        failure.gate_error = error
        failure.stop_reason = stop
        return failure

    def check(
        self,
        source: Callable[[], ExecutionGate],
        *,
        generation: int,
        monotonic: Callable[[], float],
    ) -> float:
        try:
            gate = source()
        except BaseException:
            raise self._rejected("cloud_disconnected") from None
        now = monotonic()
        if not isinstance(gate, ExecutionGate):
            raise self._rejected("cloud_disconnected")
        failure = _gate_failure(gate, generation)
        if failure is not None:
            raise self._rejected(*failure)
        with self._lock:
            if gate.server_time_ms < self._last_server_time_ms:
                raise self._rejected("cloud_disconnected")
            if gate.server_time_ms == self._last_server_time_ms:
                if now - self._last_advance > _MAX_GATE_STALE_SECONDS:
                    raise self._rejected("cloud_disconnected")
            else:
                self._last_server_time_ms = gate.server_time_ms
                self._last_advance = now
            self._grant_deadline = min(
                self._grant_deadline,
                now + (self._grant["expires_at_ms"] - gate.server_time_ms) / 1000,
            )
            self._proof_deadline = min(
                self._proof_deadline,
                now + (gate.proof_expires_at_ms - gate.server_time_ms) / 1000,
            )
            deadline = min(self._grant_deadline, self._proof_deadline)
            if now >= deadline:
                raise self._rejected("proof_expired")
            return deadline


def _verify_runner_projection(projection: Mapping[str, Any], identity: RunnerIdentity) -> None:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    try:
        public_bytes = base64.b64decode(identity.public_key_b64, validate=True)
    except (TypeError, ValueError):
        raise ValueError("runner identity public key is invalid") from None
    unsigned = {
        key: value for key, value in projection.items()
        if key not in {"projection_digest", "signing_key_id", "signature_b64"}
    }
    verify_envelope(
        {identity.key_id: Ed25519PublicKey.from_public_bytes(public_bytes)},
        {
            "signing_key_id": projection["signing_key_id"],
            "signature_b64": projection["signature_b64"],
        },
        canonical_bytes(unsigned),
    )


def _gate_failure(gate: ExecutionGate, generation: int) -> tuple[str, str] | None:
    if gate.runner_state in {"revoked", "replaced"}:
        return "runner_fault", "runner_revoked"
    if gate.proof_state == "revoked":
        return "proof_expired", "target_revoked"
    if gate.proof_state != "valid" or gate.proof_expires_at_ms <= gate.server_time_ms:
        return "proof_expired", "none"
    if gate.kill_switch_generation != generation:
        return "platform_fault", "kill_switch"
    if not gate.active:
        return "platform_fault", "kill_switch"
    if gate.stop_reason != "none":
        return "none", gate.stop_reason
    return None


def validate_execution_bundle(
    bundle: ExecutionBundle,
    *,
    store: RunnerStore,
    identity: RunnerIdentity,
    trusted_grant_keys: Mapping[str, object],
    now_ms: int,
    gate: ExecutionGate,
) -> ValidatedExecutionBundle:
    """Verify every exact immutable binding before target transport can be constructed."""
    if not isinstance(bundle, ExecutionBundle):
        raise ValueError("ExecutionBundle is required")
    if not isinstance(store, RunnerStore) or not isinstance(identity, RunnerIdentity):
        raise ValueError("bound runner store and identity are required")
    if isinstance(now_ms, bool) or not isinstance(now_ms, int) or now_ms < 0:
        raise ValueError("execution time must be a non-negative integer")
    manifest = validate_runner_test_manifest(bundle.manifest)
    projection = validate_runner_approval_projection(bundle.projection)
    grant = validate_execution_grant(bundle.grant)
    stored_manifest, stored_projection = store.load_approved_pair(projection["projection_id"])
    if stored_manifest != manifest or stored_projection != projection:
        raise ValueError("execution artifacts differ from the immutable local pair")
    _verify_runner_projection(projection, identity)
    grant_unsigned = {
        key: value for key, value in grant.items()
        if key not in {"grant_digest", "signing_key_id", "signature_b64"}
    }
    verify_envelope(
        dict(trusted_grant_keys),
        {"signing_key_id": grant["signing_key_id"], "signature_b64": grant["signature_b64"]},
        canonical_bytes(grant_unsigned),
    )
    context = store.load_context()
    binding = store.load_binding()["identity"]
    exact_approval = {
        "projection_id": projection["projection_id"],
        "projection_digest": projection["projection_digest"],
        "manifest_digest": manifest["manifest_digest"],
    }
    exact_runner_binding = {
        "runner_id": identity.runner_id,
        "runner_key_id": identity.key_id,
        "public_key_digest": identity.fingerprint,
    }
    expected_environment = {
        "environment_id": context.environment_id,
        "verification_record_digest": context.verification_record_digest,
        "origin": context.origin,
        "environment_class": context.environment_class,
    }
    if (
        manifest["environment"] != expected_environment
        or projection["environment"] != expected_environment
        or grant["environment"] != expected_environment
        or expected_environment["environment_class"] not in {"staging", "sandbox"}
        or manifest["workspace_id"] != context.workspace_id
        or projection["workspace_id"] != context.workspace_id
        or grant["workspace_id"] != context.workspace_id
        or manifest["project_id"] != context.project_id
        or projection["project_id"] != context.project_id
        or grant["project_id"] != context.project_id
        or grant["approval"] != exact_approval
        or grant["runner_binding"] != exact_runner_binding
        or binding["runner_id"] != identity.runner_id
        or binding["runner_key_id"] != identity.key_id
        or binding["fingerprint"] != identity.fingerprint
        or manifest["runner"] != {
            "runner_id": identity.runner_id,
            "runner_key_id": identity.key_id,
            "minimum_runner_version": identity.runner_version,
        }
        or projection["runner"]["runner_id"] != identity.runner_id
        or projection["runner"]["runner_key_id"] != identity.key_id
        or projection["runner"]["runner_version"] != identity.runner_version
    ):
        raise ValueError("execution bundle has a cross-binding mismatch")
    for field in ("budgets", "egress", "retry_policy"):
        if grant[field] != manifest[field] or projection[field] != manifest[field]:
            raise ValueError("execution grant cannot use different or lower approved limits")
    if manifest["compiler"] != projection["compiler"]:
        raise ValueError("execution compiler versions differ")
    expected_adapters = sorted({item["adapter_version"] for item in _units(manifest)})
    shown_units = (
        [configured_projection_instance(item) for item in manifest["test_instances"]]
        if _configured(manifest) else manifest["scenarios"]
    )
    if (
        _configured(manifest) != ("test_instances" in projection)
        or projection.get("test_instances", projection.get("scenarios")) != shown_units
        or projection["runner"]["adapter_versions"] != expected_adapters
        or any(
            identity.adapter_versions.get(item["scenario_id"]) != item["adapter_version"]
            for item in _units(manifest)
        )
    ):
        raise ValueError("execution adapter versions differ")
    if not grant["issued_at_ms"] <= now_ms < grant["expires_at_ms"]:
        raise ValueError("execution grant is expired or not yet valid")
    failure = _gate_failure(gate, grant["kill_switch_generation"])
    if failure is not None:
        raise ValueError("fresh execution gate rejected the grant")
    return ValidatedExecutionBundle(manifest, projection, grant)


def _sign_projection(unsigned: dict[str, Any], signer: SecureSigner, digest_field: str) -> dict[str, Any]:
    signature = signer.sign(canonical_bytes(unsigned))
    if not isinstance(signature, bytes) or len(signature) != 64:
        raise ValueError("runner signer returned an invalid projection signature")
    return {
        **unsigned,
        digest_field: canonical_digest(unsigned),
        "signing_key_id": signer.key_id,
        "signature_b64": base64.b64encode(signature).decode("ascii"),
    }


def _credential_value(profile: str, secret: bytes) -> object:
    if profile in {"bearer", "x_api_key"}:
        try:
            return secret.decode("ascii")
        except UnicodeError:
            raise VaultUnavailable("credential token is not transport-safe") from None
    if profile == "cookie_jar":
        value = json.loads(secret.decode("utf-8"))
        return {cookie["name"]: cookie["value"] for cookie in value["cookies"]}
    raise VaultUnavailable("invalid execution credential profile")


class LocalCanaryExecutor:
    """Prepare the complete action set, resolve all secrets, then run one request at a time."""

    def __init__(
        self,
        *,
        store: RunnerStore,
        identity: RunnerIdentity,
        signer: SecureSigner,
        trusted_grant_keys: Mapping[str, object],
        vaults: Mapping[str, object] | None = None,
        clock_ms: Callable[[], int] = lambda: int(time.time() * 1000),
        monotonic: Callable[[], float] = time.monotonic,
    ):
        if not isinstance(store, RunnerStore) or not isinstance(identity, RunnerIdentity):
            raise ValueError("bound runner store and identity are required")
        if not isinstance(signer, SecureSigner) or signer.key_id != identity.key_id:
            raise ValueError("paired runner signer is required")
        store._assert_runtime_authority(identity, signer)
        self.store = store
        self.identity = identity
        self.signer = signer
        self.trusted_grant_keys = dict(trusted_grant_keys)
        self.vaults = dict(vaults or {})
        self.clock_ms = clock_ms
        self.monotonic = monotonic
        self._active_lock = threading.Lock()
        # Serializes local activation with stop preparation: the activation linearization point.
        self._stop_lock = threading.Lock()
        self._active_context: dict[str, Any] | None = None

    def _gate(self, source: Callable[[], ExecutionGate], generation: int) -> ExecutionGate:
        try:
            gate = source()
        except BaseException:
            raise TransportFailure("gate_rejected") from None
        if not isinstance(gate, ExecutionGate):
            raise TransportFailure("gate_rejected")
        failure = _gate_failure(gate, generation)
        if failure is not None:
            error, stop = failure
            code = "cancelled" if stop != "none" else "gate_rejected"
            raised = TransportFailure(code)
            raised.gate_error = error
            raised.stop_reason = stop
            raise raised
        return gate

    def _resolve_credentials(
        self, manifest: Mapping[str, Any],
    ) -> tuple[dict[str, object], tuple[str, ...]]:
        records = {item["credential_handle_id"]: item for item in self.store.list_credentials()}
        result: dict[str, object] = {}
        redaction_secrets: set[str] = set()
        origin = manifest["environment"]["origin"]
        for binding in manifest["credential_bindings"]:
            handle = binding["credential_handle_id"]
            record = records.get(handle)
            if (
                record is None
                or record["state"] != "active"
                or record["semantic_role"] != binding["semantic_role"]
                or record["auth_profile"] != binding["auth_profile"]
            ):
                raise VaultUnavailable("credential binding is unavailable")
            vault = self.vaults.get(record["backend"])
            if vault is None and record["backend"] in {"ephemeral_env", "ephemeral_fd"}:
                vault = EphemeralVault(handle, source_kind=record["source_kind"])
            if (
                vault is None
                or getattr(vault, "supported", False) is not True
                or getattr(vault, "backend_id", record["backend"]) != record["backend"]
            ):
                raise VaultUnavailable("credential backend is unavailable")
            normalized = validate_credential_secret(
                record["auth_profile"], vault.load(handle), origin,
            )
            credential = _credential_value(record["auth_profile"], normalized)
            result[record["semantic_role"]] = credential
            if isinstance(credential, str):
                redaction_secrets.add(credential)
            elif isinstance(credential, Mapping):
                redaction_secrets.update(
                    value for value in credential.values()
                    if isinstance(value, str) and len(value.encode("utf-8")) >= 4
                )
            normalized = b""
        return result, tuple(sorted(redaction_secrets))

    def _set_active_context(self, value: dict[str, Any] | None) -> None:
        with self._active_lock:
            self._active_context = value

    def prepare_stop_ack(
        self, run_id: str, *, stop_reason: str, proposed_at_ms: int,
    ) -> dict[str, Any]:
        """Build the signed stop receipt while target execution unwinds separately."""
        if type(run_id) is not str or not run_id:
            raise ValueError("stop acknowledgement run ID is invalid")
        if stop_reason not in {
            "local_emergency_stop", "cloud_stop", "runner_revoked",
            "target_revoked", "kill_switch",
        }:
            raise ValueError("stop acknowledgement reason is invalid")
        if isinstance(proposed_at_ms, bool) or not isinstance(proposed_at_ms, int) or proposed_at_ms < 0:
            raise ValueError("stop acknowledgement timestamp is invalid")
        with self._stop_lock:
            # The caller chose this stop before calling.  An activation that has not yet taken
            # this lock will observe it and refuse, so a missing context is final: there is no
            # local receipt to anchor an acknowledgement.
            with self._active_lock:
                context = self._active_context
            if context is None or context["grant"]["run_id"] != run_id:
                raise LocalRunNotActive("no locally activated run matches the stop")
            manifest = context["manifest"]
            projection = context["projection"]
            grant = context["grant"]
            started_at = context["started_at"]
            started_monotonic = context["started_monotonic"]
            budget_lock = context["budget_lock"]
            log = context["log"]
            with budget_lock:
                counters = dict(context["counters"])
            redaction_count = context["redaction_state"]["count"]
            state = self.store.load_run(run_id)
            if state["state"] == "running":
                self.store.transition_run(
                    run_id, "stop_requested",
                    now_ms=max(self.clock_ms(), state["updated_at_ms"]),
                )
            elif state["state"] not in {"stop_requested", "finalizing"}:
                raise RunnerStoreError("active run cannot acknowledge a stop")
            events = log.load()
            if (
                not events
                or events[-1]["event_code"] != "stop_observed"
                or events[-1]["detail_code"] != stop_reason
            ):
                log.append("stop_observed", detail_code=stop_reason, counters=counters)
                events = log.load()
        requested_at = max(started_at, proposed_at_ms)
        remaining_wall = max(
            0,
            manifest["budgets"]["wall_timeout_ms"]
            - int(max(0.0, self.monotonic() - started_monotonic) * 1000),
        )
        unsigned = {
            "schema_version": OPERATIONAL_RUN_SCHEMA,
            "run_id": grant["run_id"], "grant_id": grant["grant_id"],
            "workspace_id": grant["workspace_id"], "project_id": grant["project_id"],
            "manifest_digest": manifest["manifest_digest"],
            "approval_projection_digest": projection["projection_digest"],
            "grant_digest": grant["grant_digest"],
            "event_sequence": events[-1]["sequence"] if events else 0,
            "lifecycle_phase": "stop_requested", "execution_disposition": None,
            "timestamps": {
                "claimed_at_ms": started_at, "started_at_ms": started_at,
                "updated_at_ms": requested_at, "stop_requested_at_ms": requested_at,
                "stop_acknowledged_at_ms": None, "terminal_at_ms": None,
            },
            "counters": {
                **counters,
                "remaining_requests": max(
                    0, manifest["budgets"]["maximum_requests"] - counters["requests_started"],
                ),
                "remaining_wall_ms": remaining_wall,
            },
            "versions": {
                "runner_version": self.identity.runner_version,
                "engine_version": manifest["compiler"]["engine_version"],
                "adapter_versions": sorted({
                    item["adapter_version"] for item in _units(manifest)
                }),
            },
            "error_category": "none", "stop_reason": stop_reason,
            "containment_codes": operational_containment_codes(events),
            "redaction_count": redaction_count,
        }
        return validate_operational_run(
            _sign_projection(unsigned, self.signer, "projection_digest")
        )

    @staticmethod
    def _failure_class(exc: BaseException) -> tuple[str, str, str]:
        if isinstance(exc, TransportFailure):
            stop = getattr(exc, "stop_reason", "none")
            gate_error = getattr(exc, "gate_error", None)
            if stop != "none":
                return "stopped", gate_error or "none", stop
            if exc.code == "cancelled" and gate_error is not None:
                return "incomplete", gate_error, "none"
            if exc.code == "cancelled":
                return "stopped", "none", "local_emergency_stop"
            if gate_error is not None:
                return "incomplete", gate_error, "none"
            if exc.code == "dns_changed":
                return "incomplete", "dns_changed", "none"
            if exc.code in {"connect_error", "timeout", "unsafe_dns", "peer_mismatch", "tls_error"}:
                return "incomplete", "target_unavailable", "none"
            if exc.code in {"response_too_large", "response_rejected", "invalid_route", "invalid_auth"}:
                return "failed", "containment_rejected", "none"
            return "failed", "runner_fault", "none"
        if isinstance(exc, VaultUnavailable):
            return "incomplete", "credential_unavailable", "none"
        if isinstance(exc, (ValueError, RunnerStoreError)):
            return "failed", "containment_rejected", "none"
        return "failed", "runner_fault", "none"

    def execute(
        self,
        bundle: ExecutionBundle,
        *,
        transport: Any = None,
        transport_factory: Callable[[], Any] | None = None,
        gate_source: Callable[[], ExecutionGate],
        cancellation: CancellationToken | None = None,
        on_progress: Callable[[dict[str, Any]], None] | None = None,
    ) -> ExecutionResult | UnactivatedExecution:
        """Run one exact grant against ``transport``, or the one ``transport_factory`` builds.

        The factory runs only after local activation, so a stop that arrives while it blocks (for
        example in DNS) finds a durable running run to acknowledge; its failure is finalized as
        this run's outcome, never retried.
        """
        if (transport is None) == (transport_factory is None) or (
            transport_factory is not None and not callable(transport_factory)
        ):
            raise TypeError("bounded local target transport is required")
        initial_gate = gate_source()
        initial_gate_monotonic = self.monotonic()
        validated = validate_execution_bundle(
            bundle, store=self.store, identity=self.identity,
            trusted_grant_keys=self.trusted_grant_keys, now_ms=self.clock_ms(), gate=initial_gate,
        )
        manifest, projection, grant = validated.manifest, validated.projection, validated.grant
        authority = _LiveAuthority(
            grant=grant, initial_gate=initial_gate, now=initial_gate_monotonic,
        )
        # Compile every closed action before consuming the grant or allowing a target socket.
        prepared = [prepare_action(_catalog_action(action)) for action in manifest["actions"]]
        configured = _configured(manifest)
        retention_expires = (
            self.clock_ms() + manifest["local_evidence_policy"]["retention_seconds"] * 1000
        )
        cancellation = cancellation or CancellationToken()
        counters = {
            "requests_started": 0,
            "requests_completed": 0,
            "response_bytes_read": 0,
            "actions_contained": 0,
            "retries_used": 0,
        }
        observations: dict[str, list[dict[str, Any]]] = {
            _unit_key(item): [] for item in _units(manifest)
        }
        scenario_codes: dict[str, set[str]] = {_unit_key(item): set() for item in _units(manifest)}
        scenario_evidence: dict[str, list[str]] = {_unit_key(item): [] for item in _units(manifest)}
        scenario_redactions: dict[str, int] = {_unit_key(item): 0 for item in _units(manifest)}
        # Configured only: frozen E1 expectations per instance and the raw responses by
        # action ordinal, both in memory for this run; nothing here is persisted or logged.
        live_inputs: dict[str, Any] = {}
        live_responses: dict[int, LiveReadResponse] = {}
        redaction_state = {"count": 0}
        budget_lock = threading.Lock()
        disposition = "completed"
        error_category = "none"
        stop_reason = "none"
        systemic_failure = False
        stop_requested_at_ms = None
        stop_acknowledged_at_ms = None
        with self._stop_lock:
            # Activation linearization point.  A stop chosen before it consumes no reservation
            # and has nothing to acknowledge; one chosen after it finds a durable running run.
            known_stop = getattr(cancellation, "stop_reason", None)
            if known_stop is not None:
                return UnactivatedExecution(known_stop)
            if self.store.probe_run_reservation(grant["run_id"]) is RunReservationProbe.RESERVED:
                # Restart recovery already reserved this exact grant for a claim whose answer was
                # lost.  Adopt only a never-activated reservation (``verified``, no containment
                # event): its retention is part of the signed marker, so the idempotent
                # ``reserve_run`` below then proves the same grant and initial state, and the
                # ``running`` transition stays the single activation point.  Any other
                # reservation keeps the fresh retention, which ``reserve_run`` refuses as before.
                try:
                    reserved = self.store.load_run(grant["run_id"])
                    adoptable = (
                        reserved["state"] == "verified"
                        and not self.store.load_run_events(grant["run_id"])
                    )
                except RunnerStoreError:
                    adoptable = False
                if adoptable:
                    retention_expires = reserved["retention_expires_at_ms"]
            self.store.reserve_run(grant, retention_expires_at_ms=retention_expires)
            log = _SerializedContainmentLog(
                ContainmentLog(
                    store=self.store, signer=self.signer, run_id=grant["run_id"],
                    grant_id=grant["grant_id"], manifest_digest=manifest["manifest_digest"],
                    clock_ms=self.clock_ms,
                )
            )
            log.append("grant_verified", detail_code="grant_exact")
            started_at = self.clock_ms()
            started_monotonic = self.monotonic()
            # ``run_started`` records local activation under the exact grant, before any secret
            # load or DNS; target activity is only ``action_started`` and the request counters.
            self.store.transition_run(grant["run_id"], "running", now_ms=started_at)
            log.append("run_started", detail_code="locally_activated", counters=counters)
            self._set_active_context({
                "manifest": manifest,
                "projection": projection,
                "grant": grant,
                "started_at": started_at,
                "started_monotonic": started_monotonic,
                "counters": counters,
                "budget_lock": budget_lock,
                "redaction_state": redaction_state,
                "log": log,
            })
        try:
            cancellation.raise_if_cancelled()
            if transport_factory is not None:
                try:
                    transport = transport_factory()
                except BaseException:
                    # A stop that won the race decides the outcome, not the factory failure.
                    cancellation.raise_if_cancelled()
                    raise
                if transport is None:
                    raise TypeError("bounded local target transport is required")
                cancellation.raise_if_cancelled()
            credentials, configured_secrets = self._resolve_credentials(manifest)
            redactor = Redactor(configured_secrets)
            if configured:
                live_inputs.update(self._resolve_live_inputs(manifest))
            retry_policy = RetryPolicy.from_mapping(manifest["retry_policy"])
            authority.check(
                gate_source, generation=grant["kill_switch_generation"],
                monotonic=self.monotonic,
            )
            for source, action in zip(manifest["actions"], prepared, strict=True):
                cancellation.raise_if_cancelled()
                unit = _unit_key(source)
                action_binding = {
                    "action_ordinal": source["ordinal"],
                    "scenario_id": source["scenario_id"],
                    "semantic_role": source["semantic_auth_role"],
                    "attempt": 1,
                }
                if configured and live_inputs[unit] is None:
                    # A frozen local input is missing or revoked: this instance sends nothing.
                    scenario_codes[unit].add("action_rejected")
                    log.append(
                        "action_rejected", detail_code="local_input_unavailable",
                        counters=counters, **action_binding,
                    )
                    continue
                log.append("admitted", detail_code="exact_action", counters=counters, **action_binding)
                credential = None if action.auth_profile == "anonymous" else credentials[action.semantic_auth_role]
                action_attempts = [0]

                def before_attempt(
                    attempt: int, previous_failure_code: str | None,
                ) -> AttemptPermit:
                    cancellation.raise_if_cancelled()
                    authority_deadline = authority.check(
                        gate_source, generation=grant["kill_switch_generation"],
                        monotonic=self.monotonic,
                    )
                    with budget_lock:
                        cancellation.raise_if_cancelled()
                        now = self.monotonic()
                        if now >= authority_deadline:
                            expired = TransportFailure("gate_rejected")
                            expired.gate_error = "proof_expired"
                            raise expired
                        if attempt != action_attempts[0] + 1 or attempt not in {1, 2}:
                            raise TransportFailure("gate_rejected")
                        if attempt == 1:
                            if previous_failure_code is not None:
                                raise TransportFailure("gate_rejected")
                        elif previous_failure_code not in retry_policy.retryable_failure_codes:
                            raise TransportFailure("gate_rejected")
                        elapsed_ms = int(max(0.0, now - started_monotonic) * 1000)
                        budget_failure = (
                            elapsed_ms >= manifest["budgets"]["wall_timeout_ms"]
                            or counters["requests_started"] >= manifest["budgets"]["maximum_requests"]
                            or (
                                attempt > 1
                                and counters["retries_used"] >= retry_policy.maximum_retries
                            )
                        )
                        if budget_failure:
                            log.append(
                                "budget_exhausted", action_ordinal=source["ordinal"],
                                scenario_id=source["scenario_id"],
                                semantic_role=source["semantic_auth_role"], attempt=attempt,
                                detail_code="budget_exhausted", counters=counters,
                            )
                            exhausted = TransportFailure("gate_rejected")
                            exhausted.gate_error = "budget_exhausted"
                            raise exhausted
                        counters["requests_started"] += 1
                        if attempt == 1:
                            counters["actions_contained"] += 1
                        else:
                            counters["retries_used"] += 1
                        action_attempts[0] = attempt
                        log.append(
                            "action_started", action_ordinal=source["ordinal"],
                            scenario_id=source["scenario_id"],
                            semantic_role=source["semantic_auth_role"], attempt=attempt,
                            detail_code="target_read", counters=counters,
                        )
                        action_deadline = now + manifest["budgets"]["action_timeout_ms"] / 1000
                        wall_deadline = (
                            started_monotonic + manifest["budgets"]["wall_timeout_ms"] / 1000
                        )
                        return AttemptPermit(min(
                            action_deadline, wall_deadline, authority_deadline,
                        ))

                content_observation = [None]
                markers = [b["fixture_id"] for b in source["fixture_bindings"]
                           if b["fixture_id"].startswith("heel-canary-")]

                def evidence_sink(evidence: BoundedResponseEvidence) -> str:
                    if (
                        not isinstance(evidence, BoundedResponseEvidence)
                        or evidence.action_ordinal != source["ordinal"]
                        or evidence.scenario_id != source["scenario_id"]
                        or evidence.semantic_auth_role != source["semantic_auth_role"]
                        or evidence.method != source["method"]
                        or evidence.route_template != source["route_template"]
                        or evidence.attempt != action_attempts[0]
                    ):
                        raise ValueError("response evidence differs from the frozen action")
                    if configured:
                        live_responses[source["ordinal"]] = LiveReadResponse(
                            evidence.status_code, bytes(evidence.raw_body),
                        )
                    else:
                        content_observation[0] = protected_content(
                            evidence.raw_body, marker=markers[0] if len(markers) == 1 else None,
                            status=evidence.status_code, method=evidence.method,
                        )
                    return self.store.store_response_evidence(
                        grant["run_id"], action_ordinal=evidence.action_ordinal,
                        attempt=evidence.attempt, status_code=evidence.status_code,
                        raw_headers=evidence.raw_headers, raw_body=evidence.raw_body,
                        expires_at_ms=retention_expires,
                    )

                try:
                    response = transport.request(
                        action,
                        credential=credential,
                        cancellation=cancellation,
                        retry_policy=retry_policy,
                        remaining_requests=max(
                            0,
                            manifest["budgets"]["maximum_requests"]
                            - counters["requests_started"],
                        ),
                        before_attempt=before_attempt,
                        evidence_context=EvidenceContext(
                            source["ordinal"], source["route_template"],
                        ),
                        evidence_sink=evidence_sink,
                        redactor=redactor,
                    )
                except TransportFailure as exc:
                    code = "dns_changed" if exc.code == "dns_changed" else "action_rejected"
                    scenario_codes[unit].add(code)
                    log.append(
                        code, detail_code=exc.code, counters=counters,
                        **{**action_binding, "attempt": max(1, action_attempts[0])},
                    )
                    raise
                attempts = getattr(response, "requests_made", 1)
                if (
                    isinstance(attempts, bool)
                    or not isinstance(attempts, int)
                    or attempts != action_attempts[0]
                ):
                    raise TransportFailure("response_rejected")
                counters["requests_completed"] += 1
                counters["response_bytes_read"] += response.response_bytes
                if (
                    counters["requests_started"] > manifest["budgets"]["maximum_requests"]
                    or counters["retries_used"] > manifest["retry_policy"]["maximum_retries"]
                    or response.response_bytes > manifest["budgets"]["maximum_response_bytes"]
                    or type(response.evidence_ref) is not str
                    or not response.evidence_ref.startswith("ev1_")
                ):
                    raise TransportFailure("response_rejected")
                scenario_evidence[unit].append(response.evidence_ref)
                scenario_redactions[unit] += response.redaction_count
                redaction_state["count"] += response.redaction_count
                if response.redaction_count:
                    scenario_codes[unit].add("redacted")
                    log.append(
                        "redacted", action_ordinal=source["ordinal"],
                        scenario_id=source["scenario_id"],
                        semantic_role=source["semantic_auth_role"], attempt=attempts,
                        detail_code="response_secret", counters=counters,
                    )
                observations[unit].append({
                    **({"action_ordinal": source["ordinal"]} if configured else {}),
                    "semantic_role": source["semantic_auth_role"],
                    "status_code": response.status_code,
                    "body_shape": response.body_shape,
                    "truncation_state": "complete",
                    **({} if configured else {"_protected": content_observation[0]}),
                })
                scenario_codes[unit].update({"admitted", "action_started", "action_completed"})
                log.append(
                    "action_completed", detail_code="bounded_response", counters=counters,
                    **{**action_binding, "attempt": attempts},
                )
                if on_progress is not None:
                    on_progress(self._running_projection(
                        manifest, projection, grant, started_at, started_monotonic,
                        counters, log.load(), redaction_state["count"],
                    ))
            # The final action callback may synchronously receive a Cloud stop.  Recheck both
            # the cancellation channel and the latest authenticated authority before choosing
            # successful finalization; there is no next action to perform these checks for us.
            cancellation.raise_if_cancelled()
            authority.check(
                gate_source, generation=grant["kill_switch_generation"],
                monotonic=self.monotonic,
            )
            cancellation.raise_if_cancelled()
        except BaseException as exc:
            if isinstance(exc, TransportFailure) and exc.code == "cancelled":
                control_error = getattr(cancellation, "control_error", None)
                control_stop = getattr(cancellation, "stop_reason", None)
                if control_error is not None:
                    exc.gate_error = control_error
                if control_stop is not None:
                    exc.stop_reason = control_stop
            systemic_failure = True
            disposition, error_category, stop_reason = self._failure_class(exc)
            if disposition == "stopped":
                acknowledgement = getattr(cancellation, "stop_ack_event", None)
                if isinstance(acknowledgement, threading.Event):
                    deadline = getattr(cancellation, "stop_ack_deadline", self.monotonic())
                    acknowledgement.wait(max(0.0, deadline - self.monotonic()))
                stop_requested_at_ms = getattr(cancellation, "stop_requested_at_ms", self.clock_ms())
                stop_acknowledged_at_ms = getattr(
                    cancellation, "stop_acknowledged_at_ms", None,
                )
                try:
                    with self._stop_lock:
                        local_state = self.store.load_run(grant["run_id"])
                        if local_state["state"] == "running":
                            self.store.transition_run(
                                grant["run_id"], "stop_requested",
                                now_ms=max(self.clock_ms(), local_state["updated_at_ms"]),
                            )
                        events = log.load()
                        if (
                            not events
                            or events[-1]["event_code"] != "stop_observed"
                            or events[-1]["detail_code"] != stop_reason
                        ):
                            log.append(
                                "stop_observed", detail_code=stop_reason, counters=counters,
                            )
                except BaseException:
                    disposition, error_category, stop_reason = "failed", "runner_fault", "none"
            elif error_category == "dns_changed":
                pass
            elif error_category == "credential_unavailable" and not log.load():
                log.append("grant_verified", detail_code="grant_exact", counters=counters)
        try:
            return self._finalize(
                manifest, projection, grant, log, observations, scenario_codes,
                scenario_evidence, scenario_redactions, counters,
                live_inputs=live_inputs, live_responses=live_responses,
                redaction_count=redaction_state["count"], started_at=started_at,
                disposition=disposition, error_category=error_category,
                stop_reason=stop_reason, systemic_failure=systemic_failure,
                stop_requested_at_ms=stop_requested_at_ms,
                stop_acknowledged_at_ms=stop_acknowledged_at_ms,
            )
        finally:
            self._set_active_context(None)

    def _running_projection(
        self, manifest, projection, grant, started_at, started_monotonic, counters,
        events, redaction_count,
    ) -> dict[str, Any]:
        now = self.clock_ms()
        unsigned = {
            "schema_version": OPERATIONAL_RUN_SCHEMA,
            "run_id": grant["run_id"], "grant_id": grant["grant_id"],
            "workspace_id": grant["workspace_id"], "project_id": grant["project_id"],
            "manifest_digest": manifest["manifest_digest"],
            "approval_projection_digest": projection["projection_digest"],
            "grant_digest": grant["grant_digest"],
            "event_sequence": events[-1]["sequence"] if events else 0,
            "lifecycle_phase": "running", "execution_disposition": None,
            "timestamps": {
                "claimed_at_ms": started_at, "started_at_ms": started_at,
                "updated_at_ms": now, "stop_requested_at_ms": None,
                "stop_acknowledged_at_ms": None, "terminal_at_ms": None,
            },
            "counters": {
                **counters,
                "remaining_requests": max(0, manifest["budgets"]["maximum_requests"] - counters["requests_started"]),
                "remaining_wall_ms": max(
                    0,
                    manifest["budgets"]["wall_timeout_ms"]
                    - int(max(0.0, self.monotonic() - started_monotonic) * 1000),
                ),
            },
            "versions": {
                "runner_version": self.identity.runner_version,
                "engine_version": manifest["compiler"]["engine_version"],
                "adapter_versions": sorted({item["adapter_version"] for item in _units(manifest)}),
            },
            "error_category": "none", "stop_reason": "none",
            "containment_codes": operational_containment_codes(events),
            "redaction_count": redaction_count,
        }
        return validate_operational_run(_sign_projection(unsigned, self.signer, "projection_digest"))

    def _plan_differential_outcome(
        self,
        run_id: str,
        actions: list[Mapping[str, Any]],
        observations: list[Mapping[str, Any]],
        references: list[str],
    ) -> str:
        """The existing markerless plan comparator over this scenario's own stored evidence.

        Consulted only after the canary adapter returned ``inconclusive`` for a completed
        ``plan_entitlement_read`` pair. A pair with any bound ``heel-canary-`` fixture stays
        with the canary decision. Exactly this scenario's lower/higher action ordinals select
        the two stored, redacted bodies; no request is made and nothing leaves the runner.
        Row 6 (``body_superset``) is ``observed``, row 7 (``lower_denied``) is ``blocked``,
        and every other row, refusal or error is ``inconclusive``.
        """
        try:
            from heel.runner.plan_differential import (
                ExecutorOutcome,
                evaluate_plan_pair,
                load_plan_pair_observations,
            )

            if (
                len(actions) != 2
                or len(observations) != 2
                or len(references) != 2
                or any(
                    binding["fixture_id"].startswith("heel-canary-")
                    for action in actions for binding in action["fixture_bindings"]
                )
            ):
                return "inconclusive"
            by_role = {action["semantic_auth_role"]: action for action in actions}
            method = actions[0]["method"]
            if (
                set(by_role) != {"lower_plan", "higher_plan"}
                or method not in {"GET", "HEAD"}
                or any(
                    action["method"] != method
                    or action["route_template"] != actions[0]["route_template"]
                    for action in actions
                )
            ):
                return "inconclusive"
            lower, higher = load_plan_pair_observations(
                self.store, run_id, references,
                lower_ordinal=by_role["lower_plan"]["ordinal"],
                higher_ordinal=by_role["higher_plan"]["ordinal"],
                now_ms=self.clock_ms(),
            )
            statuses = {item["semantic_role"]: item["status_code"] for item in observations}
            if (
                lower is None
                or higher is None
                or statuses != {"lower_plan": lower.status, "higher_plan": higher.status}
            ):
                return "inconclusive"
            verdict = evaluate_plan_pair(
                lower, higher, method=method, marker=None,
                executor_outcome=ExecutorOutcome("completed", "inconclusive"),
            )
        except Exception:
            return "inconclusive"
        if (verdict.row, verdict.verdict, verdict.evidence_state, verdict.predicate) == (
            6, "finding", "observed", "body_superset",
        ):
            return "observed"
        if (verdict.row, verdict.verdict, verdict.predicate, verdict.reason) == (
            7, "held", "status_parity", "lower_denied",
        ):
            return "blocked"
        return "inconclusive"

    def _finalize(
        self,
        manifest,
        projection,
        grant,
        log,
        observations,
        scenario_codes,
        scenario_evidence,
        scenario_redactions,
        counters,
        *,
        live_inputs=None,
        live_responses=None,
        redaction_count,
        started_at,
        disposition,
        error_category,
        stop_reason,
        systemic_failure,
        stop_requested_at_ms,
        stop_acknowledged_at_ms,
    ) -> ExecutionResult:
        state = self.store.load_run(grant["run_id"])
        if state["state"] in {"verified", "running", "stop_requested"}:
            state = self.store.transition_run(
                grant["run_id"], "finalizing", now_ms=self.clock_ms(),
            )
        existing_events = log.load()
        if not existing_events or existing_events[-1]["event_code"] != "run_finalized":
            log.append("run_finalized", detail_code=disposition, counters=counters)
        if _configured(manifest):
            scenario_results, outcomes = self._configured_results(
                manifest, observations, scenario_codes, scenario_evidence, scenario_redactions,
                live_inputs or {}, live_responses or {}, systemic_failure=systemic_failure,
            )
        else:
            scenario_results, outcomes = self._catalog_results(
                manifest, grant, observations, scenario_codes, scenario_evidence,
                scenario_redactions, systemic_failure=systemic_failure,
            )
        return self._finish(
            manifest, projection, grant, log, counters, scenario_results, outcomes,
            redaction_count=redaction_count, started_at=started_at, state=state,
            disposition=disposition, error_category=error_category, stop_reason=stop_reason,
            systemic_failure=systemic_failure, stop_requested_at_ms=stop_requested_at_ms,
            stop_acknowledged_at_ms=stop_acknowledged_at_ms,
        )

    def _resolve_live_inputs(self, manifest: Mapping[str, Any]) -> dict[str, Any]:
        """Snapshot every instance's frozen local inputs once, before any target request.

        Only the exact approved handles are read, never a mutable name. A missing, revoked or
        unreadable handle makes that instance ``None`` (refused, inconclusive), never false.
        """
        resolved: dict[str, Any] = {}
        for instance in manifest["test_instances"]:
            assertion = validate_live_read_assertion(instance["assertion"])
            handles = {item["fixture_ref"]: item["input_handle_id"] for item in instance["local_inputs"]}
            try:
                values = self.store.load_live_input_values(handles, vaults=self.vaults)
            except LiveInputUnavailable:
                resolved[instance["test_instance_id"]] = None
                continue
            resolved[instance["test_instance_id"]] = (
                assertion, resolve_local_fixtures(assertion, values),
            )
            values = {}
        return resolved

    def _configured_results(
        self, manifest, observations, scenario_codes, scenario_evidence, scenario_redactions,
        live_inputs, live_responses, *, systemic_failure,
    ):
        """E1 verdict per configured instance on its own two signed action ordinals.

        No catalog predicate or plan comparator is ever consulted for a configured instance.
        """
        results, outcomes = [], []
        for ordinal, instance in enumerate(manifest["test_instances"]):
            key = instance["test_instance_id"]
            restricted_ordinal, control_ordinal = 2 * ordinal, 2 * ordinal + 1
            # Absent: inputs were never resolved (failure before resolution, or recovery) ->
            # run_incomplete. Present but None: the frozen handle was refused.
            frozen = live_inputs.get(key, _UNRESOLVED)
            outcome, reason, control, restricted = "inconclusive", "run_incomplete", "not_established", "not_observed"
            if frozen is _UNRESOLVED:
                pass
            elif frozen is None:
                reason = "local_input_unavailable"
            elif (
                not systemic_failure
                and len(observations[key]) == 2
                and restricted_ordinal in live_responses
                and control_ordinal in live_responses
            ):
                assertion, expectations = frozen
                verdict = evaluate_live_read_pair(
                    role_policy=instance["scenario_id"], method=instance["method"],
                    assertion=assertion, expectations=expectations,
                    control=live_responses[control_ordinal],
                    restricted=live_responses[restricted_ordinal],
                )
                outcome, reason = verdict.outcome, verdict.reason
                control = "established" if verdict.positive_control else "not_established"
                restricted = {True: "true", False: "false"}.get(verdict.restricted_condition, "not_observed")
            outcomes.append(outcome)
            results.append({
                "ordinal": ordinal,
                "test_instance_id": key,
                "scenario_id": instance["scenario_id"],
                "adapter_version": instance["adapter_version"],
                "source": dict(instance["source"]),
                "assertion_digest": instance["assertion_digest"],
                "condition_kind": instance["assertion"]["condition"]["kind"],
                "route": {"method": instance["method"], "route_template": instance["route_template"]},
                "assessment_outcome": outcome,
                "reason": reason,
                "positive_control": control,
                "restricted_condition": restricted,
                "observations": sorted(observations[key], key=lambda item: item["action_ordinal"]),
                "finding": _configured_finding() if outcome == "observed" else None,
                "containment_codes": sorted(scenario_codes[key]),
                "redaction_count": scenario_redactions[key],
                "local_evidence_refs": sorted(scenario_evidence[key]),
            })
        return results, outcomes

    def _catalog_results(
        self, manifest, grant, observations, scenario_codes, scenario_evidence,
        scenario_redactions, *, systemic_failure,
    ):
        scenario_results = []
        outcomes = []
        actions_by_scenario: dict[str, list[Mapping[str, Any]]] = {}
        for action in manifest["actions"]:
            actions_by_scenario.setdefault(action["scenario_id"], []).append(action)
        for ordinal, scenario in enumerate(manifest["scenarios"]):
            scenario_id = scenario["scenario_id"]
            scenario_observations = observations[scenario_id]
            source_actions = actions_by_scenario[scenario_id]
            plan_differential = False
            if systemic_failure or len(scenario_observations) != len(source_actions):
                outcome = "inconclusive"
            else:
                pair = evaluate_pair(
                    scenario_id,
                    scenario_observations[0]["status_code"],
                    scenario_observations[1]["status_code"],
                    method=source_actions[0]["method"],
                    first_body_shape=scenario_observations[0]["body_shape"],
                    second_body_shape=scenario_observations[1]["body_shape"],
                    first_protected=scenario_observations[0].get("_protected"),
                    second_protected=scenario_observations[1].get("_protected"),
                )
                outcome = pair.outcome
                if outcome == "inconclusive" and scenario_id == _PLAN_SCENARIO:
                    outcome = self._plan_differential_outcome(
                        grant["run_id"], source_actions, scenario_observations,
                        scenario_evidence[scenario_id],
                    )
                    plan_differential = True
            # The local content predicate is not part of the disclosure schema.
            for observation in scenario_observations:
                observation.pop("_protected", None)
            outcomes.append(outcome)
            finding = None
            if outcome == "observed" and plan_differential:
                finding = _plan_differential_finding()
            elif outcome == "observed":
                finding = {
                    "title": "Canary authorization boundary was crossed",
                    "reachability_rationale": "Both isolated canary roles received the exact approved protected marker; the entitled positive control succeeded. Only this read was tested.",
                    "confidence": "high",
                    "recommended_control": "Enforce the selected authorization boundary on every object read.",
                    "regression_suggestion": "Repeat this exact catalog scenario with a new one-shot grant.",
                }
            scenario_results.append({
                "ordinal": ordinal,
                "scenario_id": scenario_id,
                "adapter_version": scenario["adapter_version"],
                "assessment_outcome": outcome,
                "route": {
                    "method": source_actions[0]["method"],
                    "route_template": source_actions[0]["route_template"],
                },
                "observations": sorted(
                    scenario_observations,
                    key=lambda item: (
                        item["semantic_role"], item["status_code"], item["body_shape"],
                        item["truncation_state"],
                    ),
                ),
                "finding": finding,
                "containment_codes": sorted(scenario_codes[scenario_id]),
                "redaction_count": scenario_redactions[scenario_id],
                "local_evidence_refs": sorted(scenario_evidence[scenario_id]),
            })
        return scenario_results, outcomes

    def _finish(
        self, manifest, projection, grant, log, counters, scenario_results, outcomes, *,
        redaction_count, started_at, state, disposition, error_category, stop_reason,
        systemic_failure, stop_requested_at_ms, stop_acknowledged_at_ms,
    ) -> ExecutionResult:
        configured = _configured(manifest)
        aggregate = (
            "inconclusive" if systemic_failure
            else "observed" if "observed" in outcomes
            else "blocked" if outcomes and all(item == "blocked" for item in outcomes)
            else "inconclusive"
        )
        # The one terminal instant: signed into the projections below and used, unchanged, for
        # the terminal transition, so the stored terminal record and the signed result agree.
        # It is never earlier than the run's current local time, which the store requires.
        finished_at = max(
            self.clock_ms(), started_at, state["updated_at_ms"],
            stop_requested_at_ms or 0, stop_acknowledged_at_ms or 0,
        )
        findings_unsigned = {
            "schema_version": CONFIGURED_FINDINGS_SCHEMA if configured else CANARY_FINDINGS_SCHEMA,
            "projection_id": "findings_" + hashlib.sha256(grant["run_id"].encode()).hexdigest()[:24],
            "run_id": grant["run_id"], "grant_id": grant["grant_id"],
            "workspace_id": grant["workspace_id"], "project_id": grant["project_id"],
            "environment_id": grant["environment"]["environment_id"],
            "manifest_digest": manifest["manifest_digest"],
            "approval_projection_digest": projection["projection_digest"],
            "grant_digest": grant["grant_digest"],
            "engine_version": manifest["compiler"]["engine_version"],
            "adapter_versions": sorted({item["adapter_version"] for item in _units(manifest)}),
            "started_at_ms": started_at, "finished_at_ms": finished_at,
            "assessment_outcome": aggregate,
            ("test_results" if configured else "scenario_results"): scenario_results,
            "containment_codes": operational_containment_codes(log.load()),
            "redaction_count": redaction_count,
        }
        findings = (validate_configured_findings if configured else validate_canary_findings)(
            _sign_projection(findings_unsigned, self.signer, "projection_digest")
        )
        operational_unsigned = {
            "schema_version": OPERATIONAL_RUN_SCHEMA,
            "run_id": grant["run_id"], "grant_id": grant["grant_id"],
            "workspace_id": grant["workspace_id"], "project_id": grant["project_id"],
            "manifest_digest": manifest["manifest_digest"],
            "approval_projection_digest": projection["projection_digest"],
            "grant_digest": grant["grant_digest"],
            "event_sequence": log.load()[-1]["sequence"],
            "lifecycle_phase": "terminal", "execution_disposition": disposition,
            "timestamps": {
                "claimed_at_ms": started_at, "started_at_ms": started_at,
                "updated_at_ms": finished_at,
                "stop_requested_at_ms": stop_requested_at_ms,
                "stop_acknowledged_at_ms": stop_acknowledged_at_ms,
                "terminal_at_ms": finished_at,
            },
            "counters": {
                **counters,
                "remaining_requests": max(0, manifest["budgets"]["maximum_requests"] - counters["requests_started"]),
                "remaining_wall_ms": 0,
            },
            "versions": {
                "runner_version": self.identity.runner_version,
                "engine_version": manifest["compiler"]["engine_version"],
                "adapter_versions": sorted({item["adapter_version"] for item in _units(manifest)}),
            },
            "error_category": error_category, "stop_reason": stop_reason,
            "containment_codes": operational_containment_codes(log.load()),
            "redaction_count": redaction_count,
        }
        operational = validate_operational_run(
            _sign_projection(operational_unsigned, self.signer, "projection_digest")
        )
        policy = grant["operational_receipt_policy"]
        if (
            len(canonical_bytes(operational)) > policy["maximum_bytes"]
            or error_category not in policy["allowed_error_categories"]
            or stop_reason not in policy["allowed_stop_reasons"]
            or any(code not in policy["allowed_containment_codes"] for code in operational["containment_codes"])
        ):
            raise ValueError("operational projection exceeds the approved receipt policy")
        log.append("local_result_ready", detail_code="safe_projection", counters=counters)
        events = log.load()
        summary = {
            "event_count": len(events),
            "head_digest": events[-1]["event_digest"],
            "codes": sorted({item["event_code"] for item in events}),
            "redaction_count": redaction_count,
        }
        local_view = validate_local_result_view({
            "schema_version": "heel.local-result-view.v1",
            "operational_projection": operational,
            "findings_projection": findings,
            "containment_summary": summary,
        })
        disclosure = validate_disclosure_preview({
            "schema_version": "heel.local-disclosure-preview.v1",
            "projection": findings,
            "projection_digest": findings["projection_digest"],
            "projection_bytes": len(canonical_bytes(findings)),
            "scenario_count": len(scenario_results),
            "finding_count": sum(item["finding"] is not None for item in scenario_results),
        })
        self.store.save_final_projections(
            grant["run_id"], operational, findings, local_view, disclosure,
        )
        self.store.transition_run(grant["run_id"], "terminal", now_ms=finished_at)
        return ExecutionResult(
            aggregate, disposition, operational, findings, local_view, disclosure,
        )

    def recover(self, run_id: str, *, transport: Any = None) -> ExecutionResult:
        """Finalize an interrupted run without ever replaying a started target action."""
        del transport
        try:
            self.store.load_run(run_id)
        except RunnerStoreError:
            self.store.recover_run_reservation(run_id)
        try:
            stored = self.store.load_final_projections(run_id)
        except RunnerStoreError:
            stored = None
        if stored is not None:
            state = self.store.load_run(run_id)["state"]
            if state != "terminal":
                # Verified finals persisted before the terminal transition: finish at the instant
                # they sign. A store time later than that instant is refused by the store.
                operational = stored["operational_projection"]
                terminal_at = operational["timestamps"]["terminal_at_ms"]
                if (
                    operational["run_id"] != run_id
                    or operational["grant_id"] != self.store.load_run_grant(run_id)["grant_id"]
                    or operational["lifecycle_phase"] != "terminal"
                    or isinstance(terminal_at, bool)
                    or not isinstance(terminal_at, int)
                    or operational["timestamps"]["updated_at_ms"] != terminal_at
                ):
                    raise RunnerStoreError("local final projections are invalid")
                if state in {"verified", "running", "stop_requested"}:
                    self.store.transition_run(run_id, "finalizing", now_ms=terminal_at)
                self.store.transition_run(run_id, "terminal", now_ms=terminal_at)
            return ExecutionResult(
                stored["findings_projection"]["assessment_outcome"],
                stored["operational_projection"]["execution_disposition"],
                stored["operational_projection"], stored["findings_projection"],
                stored["local_view"], stored["disclosure_preview"],
            )
        grant = self.store.load_run_grant(run_id)
        manifest = self.store.load_manifest(grant["approval"]["manifest_digest"])
        projection = self.store.load_projection(grant["approval"]["projection_id"])
        validate_execution_bundle(
            ExecutionBundle(manifest, projection, grant),
            store=self.store,
            identity=self.identity,
            trusted_grant_keys=self.trusted_grant_keys,
            now_ms=grant["issued_at_ms"],
            gate=ExecutionGate(
                active=True,
                runner_state="active",
                proof_state="valid",
                proof_expires_at_ms=max(grant["expires_at_ms"], grant["issued_at_ms"] + 1),
                kill_switch_generation=grant["kill_switch_generation"],
                stop_reason="none",
                server_time_ms=grant["issued_at_ms"],
            ),
        )
        log = ContainmentLog(
            store=self.store, signer=self.signer, run_id=run_id, grant_id=grant["grant_id"],
            manifest_digest=manifest["manifest_digest"], clock_ms=self.clock_ms,
        )
        events = log.load()
        if not events:
            log.append("grant_verified", detail_code="recovery_verified")
            events = log.load()
        counters = copy.deepcopy(events[-1]["counters"])
        observations = {_unit_key(item): [] for item in _units(manifest)}
        codes = {_unit_key(item): set() for item in _units(manifest)}
        evidence = {_unit_key(item): [] for item in _units(manifest)}
        redactions = {_unit_key(item): 0 for item in _units(manifest)}
        return self._finalize(
            manifest, projection, grant, log, observations, codes, evidence, redactions, counters,
            redaction_count=0,
            started_at=events[0]["occurred_at_ms"], disposition="incomplete",
            error_category="runner_fault", stop_reason="none", systemic_failure=True,
            stop_requested_at_ms=None, stop_acknowledged_at_ms=None,
        )


__all__ = [
    "ExecutionBundle", "ExecutionGate", "ExecutionResult", "LocalCanaryExecutor",
    "LocalRunNotActive", "UnactivatedExecution", "ValidatedExecutionBundle",
    "validate_execution_bundle",
]
