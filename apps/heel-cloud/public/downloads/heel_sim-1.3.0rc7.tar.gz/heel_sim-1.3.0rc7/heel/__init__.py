"""Heel: MCP-first SaaS abuse rehearsal before launch and continuously after.

Synthetic-target backtests are the evaluation spine; the safety spine in section 10 is
non-negotiable.
"""
__version__ = "1.3.0rc7"
